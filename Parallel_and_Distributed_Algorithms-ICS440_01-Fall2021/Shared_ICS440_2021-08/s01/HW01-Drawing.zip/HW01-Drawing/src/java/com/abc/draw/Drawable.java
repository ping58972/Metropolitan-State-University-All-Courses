package com.abc.draw;

import java.awt.*;

public interface Drawable {
	void draw(Graphics2D g2);
}
