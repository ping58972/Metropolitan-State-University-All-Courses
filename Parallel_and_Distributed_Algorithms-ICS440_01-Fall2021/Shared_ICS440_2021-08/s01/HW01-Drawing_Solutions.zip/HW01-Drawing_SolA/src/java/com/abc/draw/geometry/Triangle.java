package com.abc.draw.geometry;

import java.awt.*;

public class Triangle {
    private final Point p1;
    private final Point p2;
    private final Point p3;

    public Triangle(Point p1, Point p2, Point p3) {
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
    }

    public void drawTri(Graphics2D g2) {
        Line l1 = new Line(p1, p2);
        l1.draw(g2);
        Line l2 = new Line(p2, p3);
        l2.draw(g2);
        Line l3 = new Line(p3, p1);
        l3.draw(g2);
    }

}
