package com.abc.draw;

import java.awt.*;

import com.abc.draw.geometry.*;

public class Drawing extends Object {
    private Line lineA;
    private Line lineB;
    private Triangle triangle;

    public Drawing() {
    }

    public void drawAll(Graphics2D g2) {
        if (lineA != null) lineA.draw(g2);
        if (lineB != null) lineB.draw(g2);
        if (triangle != null) triangle.drawTri(g2);
    }

    public void append(Line line) {
        if (lineA == null) {
            lineA = line;
        } else if (lineB == null) {
            lineB = line;
        } else {
            throw new RuntimeException("hey, that's too many lines...");
        }
    }

    public void append(Triangle t1) {
        if (triangle == null) triangle = t1;
    }
}