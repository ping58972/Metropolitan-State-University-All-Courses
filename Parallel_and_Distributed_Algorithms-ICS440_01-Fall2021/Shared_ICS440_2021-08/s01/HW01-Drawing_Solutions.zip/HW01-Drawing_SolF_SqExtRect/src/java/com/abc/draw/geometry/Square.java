package com.abc.draw.geometry;

public class Square extends Rectangle {
    public Square(Point upperLeft, double width) {
        super(upperLeft, width, width);
    }

    @Override
    public void setWidth(double width) {
        super.setWidth(width);
        super.setHeight(width);
    }

    @Override
    public void setHeight(double height) {
        setWidth(height);
    }

    @Override
    public void setSize(double width, double height) {
        super.setSize(width, width);
    }
}
