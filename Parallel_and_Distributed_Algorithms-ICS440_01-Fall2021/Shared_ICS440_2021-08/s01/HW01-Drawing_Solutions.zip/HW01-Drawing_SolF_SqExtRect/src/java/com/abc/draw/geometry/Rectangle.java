package com.abc.draw.geometry;

import java.awt.*;

import com.abc.draw.*;

public class Rectangle implements Drawable {
    private final Point upperLeft;
    private double width;
    private double height;

    public Rectangle(Point upperLeft, double width, double height) {
        this.upperLeft = upperLeft;
        this.width = width;
        this.height = height;
    }

    public Point getUpperLeft() {
        return upperLeft;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    public void setSize(double width, double height) {
        this.width = width;
        this.height = height;
    }

    @Override
    public void draw(Graphics2D g2) {
        Paint origPaint = g2.getPaint();
        Stroke origStroke = g2.getStroke();
        try {
            g2.setPaint(Color.MAGENTA);
            g2.setStroke(new BasicStroke(10.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

            SmoothPath path = new SmoothPath();
            path.moveTo(upperLeft);
            path.horizontalLine(width);
            path.verticalLine(height);
            path.horizontalLine(-width);
            path.closePath();

            path.draw(g2);
        } finally {
            g2.setStroke(origStroke);
            g2.setPaint(origPaint);
        }
    }
}
