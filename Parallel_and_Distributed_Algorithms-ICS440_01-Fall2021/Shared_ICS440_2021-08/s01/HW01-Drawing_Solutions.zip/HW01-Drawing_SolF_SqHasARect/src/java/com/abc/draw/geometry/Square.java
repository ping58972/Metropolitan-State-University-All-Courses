package com.abc.draw.geometry;

import java.awt.*;

import com.abc.draw.*;

public class Square implements Drawable {
    private final Rectangle rect;

    public Square(Point upperLeft, double width) {
        rect = new Rectangle(upperLeft, width, width);
    }

    public Point getUpperLeft() {
        return rect.getUpperLeft();
    }

    public double getWidth() {
        return rect.getWidth();
    }

    public void setWidth(double width) {
        rect.setWidth(width);
        rect.setHeight(width);
    }

    @Override
    public void draw(Graphics2D g2) {
        rect.draw(g2);
    }
}
