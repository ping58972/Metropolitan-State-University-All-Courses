package com.abc.draw.geometry;

public class GeomTools {
    // no instances
    private GeomTools() {
    }

    public static double calcPerimeter(Rectangle r) {
        return r.getWidth() * 2 + r.getHeight() * 2;
    }

    public static double calcPerimeter(Square s) {
        return s.getWidth() * 4;
    }

    public static void doubleWidthAndHeight(Rectangle r) {
        r.setSize(r.getWidth() * 2.0, r.getHeight() * 2.0);
    }

    public static void doubleWidthAndHalfHeight(Rectangle r) {
        r.setSize(r.getWidth() * 2.0, r.getHeight() / 2.0);
    }

    public static void doubleWidth(Square s) {
        s.setWidth(s.getWidth() * 2.0);
    }
}
