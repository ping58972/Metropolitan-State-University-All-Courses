package com.abc.draw.geometry;

import java.awt.*;

import com.abc.draw.*;

public class Triangle implements Drawable {
    private final Point p1;
    private final Point p2;
    private final Point p3;
    private final SmoothPath path;

    public Triangle(Point p1, Point p2, Point p3) {
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;

        path = new SmoothPath();
        path.moveTo(p1);
        path.lineTo(p2);
        path.lineTo(p3);
        path.closePath();
    }

    public Point getP1() {
        return p1;
    }

    public Point getP2() {
        return p2;
    }

    public Point getP3() {
        return p3;
    }

    @Override
    public void draw(Graphics2D g2) {
        Paint origPaint = g2.getPaint();
        Stroke origStroke = g2.getStroke();
        try {
            g2.setPaint(Color.RED);
            //g2.setStroke(new BasicStroke(25.0f));
            g2.setStroke(new BasicStroke(20.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

            path.draw(g2);
        } finally {
            g2.setStroke(origStroke);
            g2.setPaint(origPaint);
        }
    }

}
