package com.abc.draw.geometry;

public class GeomTools {
    // no instances
    private GeomTools() {
    }

    public static double calcPerimeter(Square s) {
        return s.getWidth() * 4;
    }
}
