package com.abc.draw.geometry;

import java.awt.*;
import java.awt.geom.*;

import com.abc.draw.*;

public class SmoothPath implements Drawable {
    private final Path2D path;

    public SmoothPath() {
        path = new Path2D.Double();
    }

    public void moveTo(Point p) {
        path.moveTo(p.getX(), p.getY());
    }

    public void lineTo(Point p) {
        path.lineTo(p.getX(), p.getY());
    }

    public void horizontalLine(double length) {
        Point2D oldPoint = path.getCurrentPoint();
        lineTo(new Point(oldPoint.getX() + length, oldPoint.getY()));
    }

    public void verticalLine(double height) {
        Point2D oldPoint = path.getCurrentPoint();
        lineTo(new Point(oldPoint.getX(), oldPoint.getY() + height));
    }

    public void closePath() {
        path.closePath();
    }

    @Override
    public void draw(Graphics2D g2) {
        g2.draw(path);
    }
}
