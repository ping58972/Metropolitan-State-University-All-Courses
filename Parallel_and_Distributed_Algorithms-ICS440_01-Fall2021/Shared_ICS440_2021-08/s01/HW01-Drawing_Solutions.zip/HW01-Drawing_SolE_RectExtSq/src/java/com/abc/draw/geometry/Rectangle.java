package com.abc.draw.geometry;

import java.awt.*;

public class Rectangle extends Square {
    private double height;

    public Rectangle(Point upperLeft, double width, double height) {
        super(upperLeft, width);
        this.height = height;
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }

    @Override
    public void draw(Graphics2D g2) {
        Paint origPaint = g2.getPaint();
        Stroke origStroke = g2.getStroke();
        try {
            g2.setPaint(Color.MAGENTA);
            g2.setStroke(new BasicStroke(10.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

            SmoothPath path = new SmoothPath();
            path.moveTo(upperLeft);
            path.horizontalLine(width);
            path.verticalLine(height);
            path.horizontalLine(-width);
            path.closePath();

            path.draw(g2);
        } finally {
            g2.setStroke(origStroke);
            g2.setPaint(origPaint);
        }
    }
}
