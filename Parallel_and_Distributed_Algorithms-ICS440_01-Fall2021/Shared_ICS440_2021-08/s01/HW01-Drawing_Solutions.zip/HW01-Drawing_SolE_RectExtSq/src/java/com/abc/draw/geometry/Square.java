package com.abc.draw.geometry;

import java.awt.*;

import com.abc.draw.*;

public class Square implements Drawable {
    protected final Point upperLeft;
    protected double width;

    public Square(Point upperLeft, double width) {
        this.upperLeft = upperLeft;
        this.width = width;
    }

    public Point getUpperLeft() {
        return upperLeft;
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    @Override
    public void draw(Graphics2D g2) {
        Paint origPaint = g2.getPaint();
        Stroke origStroke = g2.getStroke();
        try {
            g2.setPaint(Color.MAGENTA);
            g2.setStroke(new BasicStroke(10.0f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

            SmoothPath path = new SmoothPath();
            path.moveTo(upperLeft);
            path.horizontalLine(width);
            path.verticalLine(width);
            path.horizontalLine(-width);
            path.closePath();

            path.draw(g2);
        } finally {
            g2.setStroke(origStroke);
            g2.setPaint(origPaint);
        }
    }

}
