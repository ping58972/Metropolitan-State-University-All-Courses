package com.abc.draw;

import java.awt.*;

public class Drawing extends Object {
    private final int growthIncrement;

    private Drawable[] drawables;
    private int count;

    public Drawing(int initialCapacity, int growthIncrement) {
        this.growthIncrement = Math.max(1, growthIncrement);

        drawables = new Drawable[Math.max(0, initialCapacity)];
        count = 0;
    }

    public Drawing() {
        this(10, 5);
    }

    public void drawAll(Graphics2D g2) {
        for (int i = 0; i < count; i++) {
            drawables[i].draw(g2);
        }
    }

    public void append(Drawable drawable) {
        if (count == drawables.length) {
            // "grow" it
            Drawable[] tmp = new Drawable[drawables.length + growthIncrement];
            //System.out.println("grow to " + tmp.length);
            System.arraycopy(drawables, 0, tmp, 0, drawables.length);
            drawables = tmp;
        }

        drawables[count] = drawable;
        count++;
    }


//    public void drawAll(Graphics2D g2) {
//        for (Drawable drawable : drawables) {
//            drawable.draw(g2);
//        }
//    }
//
//    public void append(Drawable drawable) {
//        Drawable[] tmp = new Drawable[drawables.length + 1];
//        System.arraycopy(drawables, 0, tmp, 0, drawables.length);
//        drawables = tmp;
//        drawables[drawables.length - 1] = drawable;
//    }
}