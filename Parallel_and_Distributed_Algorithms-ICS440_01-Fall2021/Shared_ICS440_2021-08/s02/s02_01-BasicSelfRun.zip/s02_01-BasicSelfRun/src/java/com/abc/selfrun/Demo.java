package com.abc.selfrun;

public class Demo {
    @SuppressWarnings("unused")
    public static void main(String[] args) {
        new WordPrinter(3);
        new WordPrinter(7);
        new WordPrinter(11);
    }
}
