package threadbook.ch12;

public interface ExceptionListener {
	public void exceptionOccurred(Exception x, Object source);
}
