package com.abc.socket;

import java.io.*;

import com.abc.log.*;

public class SocketServer {
    private final Log log;
    
    public SocketServer(int port, Log log) throws IOException {
        this.log = log;
        
        log.outln("Attempting to begin accepting connections on port " + port);
        
        // TODO - setup a ServerSocket
        //
        // TODO - spawn an internal thread to wait for connections
    }
    
    private void runWork() {
        // TODO - Accept socket connections for clients...
        //
        // TODO - For each accepted socket, create a new thread (possibly
        //        in another self-running object) to wait for client requests
        //        to be sent up and then send back the appropriate response.
        //        
        // TODO - Be ready to handle multiple simultaneous conversations
        //        with different clients.
    }
}
