package com.abc.socket;

import java.io.*;

import com.abc.log.*;

public class SocketClient {
    private final Log log;
    private final RequestResponseMapping requestResponseMapping;
    
    // OK to add more variables...
    
    public SocketClient(String host, int port, Log log) throws IOException {
        this.log = log;
        this.requestResponseMapping = RequestResponseMapping.getInstance();
        
        log.outln("Attempting to connect to " + host + ":" + port);

        // TODO - do more here...
    }
    
    public String chat(String request) throws IOException {
        // TODO - fix this so that the request is sent to the server and
        //        the response is returned.
        return null;
    }
    
    public void disconnect() throws IOException {
        // TODO - send the goodbye stuff and then close the connection
    }
}
