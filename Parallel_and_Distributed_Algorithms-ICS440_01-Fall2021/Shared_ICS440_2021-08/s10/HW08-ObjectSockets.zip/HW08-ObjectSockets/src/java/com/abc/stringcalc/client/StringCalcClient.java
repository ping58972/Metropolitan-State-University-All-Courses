package com.abc.stringcalc.client;

import java.io.*;
import java.net.*;

import com.abc.stringcalc.dto.*;
import com.abc.stringcalc.util.*;
import com.programix.io.*;

public class StringCalcClient {
    private Socket socket;
    private ObjectOutputStream oos;
    private ObjectInputStream ois;
    private Log log;
    
    public StringCalcClient(String hostname, int port, Log log) 
            throws IOException {
        
        this.log = log;
        
        log.outln("Attempting to connect to " + hostname + ":" + port);
        
        //
        // TODO - Create socket and object streams...
        //
    }

    public void disconnect() throws IOException {
        //
        // TODO - Disconnect from the server in a graceful manner
        //
    }
    
    public StringCalcResponse calculate(StringCalcRequest req) 
            throws IOException {

        //
        // TODO - Send the request to the server and then receive the response.
        //
        return null;
    }
}
