package com.abc.stringcalc.server;

import java.io.*;
import java.net.*;

import com.abc.stringcalc.dto.*;
import com.abc.stringcalc.util.*;
import com.programix.io.*;

public class StringCalcServer {
    private ServerSocket ss;
    private Log log;

    public StringCalcServer(int port, Log log) throws IOException {
        this.log = log;

        log.outln("Attempting to begin accepting connections on port " + port);

        //
        // TODO - Create ServerSocket and start an internal thread...
        //
    }

    private void runWork() {
        try {
            log.outln(
                "StringCalcServer ready on port: " + ss.getLocalPort());

            for (int count = 0; true; count++ ) {
                //
                // TODO - Each time through the loop, accept socket connections
                //        from a client and hand off that socket to a new
                //        instance of a self-running object dedicated to the
                //        conversation.
                //
            }
        } catch ( Exception x ) {
            log.out(x);
        } finally {
            IOTools.closeQuietly(ss);
            log.outln("StringCalcServer exiting.");
        }
    }

    private class Session implements Runnable {
        private final Socket sock;
        private final int id;
        private boolean dontExpectClientToCloseSocket;

        public Session(Socket sock, int id) {
            this.sock = sock;
            this.id = id;
            this.dontExpectClientToCloseSocket = true;

            Thread t = new Thread(this, "Session-" + id);
            t.start();
        }

        @Override
        public void run() {
            ObjectInputStream ois = null;
            ObjectOutputStream oos = null;

            log.outln("Starting conversation #" + id +
                ". Talking with " + sock.getInetAddress().getHostAddress());

                //
                // TODO - Setup object streams with the client.
                //

                while ( true ) {
                    //
                    // TODO - Receive client requests, process, and send the
                    //        responses. If a DisconnectRequest is received
                    //        prepare for a graceful shutdown.
                    //
                }

                // TODO - cleanup
        }

        private StringCalcResponse process(StringCalcRequest req) {
            StringCalculator sc =
                new StringCalculator(req.getData(), req.isIgnoreNulls());

            StringCalcResponse res = new StringCalcResponse();
            res.setCount(sc.getCount());
            res.setTotalLength(sc.getTotalLength());
            res.setMaxLength(sc.getMaxLength());
            res.setMinLength(sc.getMinLength());
            res.setAverageLength(sc.getAverageLength());
            return res;
        }
    } // class Session
}
