package com.abc.ds.keyvalue;

public interface DSKeyValuePair<K, V> {
    K getKey();
    V getValue();
}
