package com.abc.stringcalc.server;

import java.io.*;
import java.net.*;

import com.abc.stringcalc.dto.*;
import com.abc.stringcalc.util.*;
import com.programix.io.*;

public class StringCalcServer {
    private ServerSocket ss;
    private Log log;

    public StringCalcServer(int port, Log log) throws IOException {
        this.log = log;
        log.outln("Attempting to begin accepting connections on port " + port);
        ss = new ServerSocket(port);

        Thread t = new Thread(() -> runWork(), "StringCalcServer");
        t.start();
    }

    @SuppressWarnings("unused")
    private void runWork() {
        try {
            log.outln("StringCalcServer ready on port: " + ss.getLocalPort());

            for (int count = 0; true; count++ ) {
                //
                // TODO - Each time through the loop, accept a socket connection
                //        from a client and hand off that socket to a new
                //        instance of a self-running object dedicated to the
                //        conversation.
                //
                new Session(ss.accept(), count);
            }
        } catch ( Exception x ) {
            log.out(x);
        } finally {
            IOTools.closeQuietly(ss);
            log.outln("StringCalcServer exiting.");
        }
    }

    private class Session implements Runnable {
        private final Socket sock;
        private final int id;
        private boolean dontExpectClientToCloseSocket;

        public Session(Socket sock, int id) {
            this.sock = sock;
            this.id = id;
            this.dontExpectClientToCloseSocket = true;

            Thread t = new Thread(this, "Session-" + id);
            t.start();
        }

        @Override
        public void run() {
            ObjectInputStream ois = null;
            ObjectOutputStream oos = null;

            log.outln("Starting conversation #" + id + ". Talking with " + sock.getInetAddress().getHostAddress());

            try {
                oos = new ObjectOutputStream(new BufferedOutputStream(sock.getOutputStream()));
                oos.flush();
                ois = new ObjectInputStream(new BufferedInputStream(sock.getInputStream()));

                while ( true ) {
                    Object obj = ois.readObject();
                    if (obj instanceof StringCalcRequest) {
                        StringCalcRequest req = (StringCalcRequest)obj;
                        StringCalcResponse res = process(req);
                        oos.writeObject(res);
                        oos.flush();
                    } else if (obj instanceof DisconnectRequest) {
                        dontExpectClientToCloseSocket = false;
                        oos.writeObject(new DisconnectResponse());
                        oos.flush();
                    } else {
                        log.outln(String.format("got an unexpected object type: %s", obj.getClass().getSimpleName()));
                    }

                    //
                    // TODO - If a DisconnectRequest is received
                    //        prepare for a graceful shutdown.
                    //
                }
            } catch (IOException x) {
                if (dontExpectClientToCloseSocket) log.out(x);
            } catch (ClassNotFoundException x) {
                log.out(x);
            } finally {
                IOTools.closeQuietly(sock, ois, oos);
                log.outln("StringCalcServer.Session exiting.");

//                try {
//                    if (ois != null) {
//                        ois.close();
//                    }
//                } catch (IOException x) {
//                    // sssssshhhh, ignore. Hey we did our best
//                }
//                try {
//                    if (oos != null) {
//                        oos.close();
//                    }
//                } catch (IOException x) {
//                    // sssssshhhh, ignore. Hey we did our best
//                }
//                try {
//                    if (sock != null) {
//                        sock.close();
//                    }
//                } catch (IOException x) {
//                    // sssssshhhh, ignore. Hey we did our best
//                }
            }
        }

        private StringCalcResponse process(StringCalcRequest req) {
            StringCalculator sc = new StringCalculator(req.getData(), req.isIgnoreNulls());

            StringCalcResponse res = new StringCalcResponse();
            res.setCount(sc.getCount());
            res.setTotalLength(sc.getTotalLength());
            res.setMaxLength(sc.getMaxLength());
            res.setMinLength(sc.getMinLength());
            res.setAverageLength(sc.getAverageLength());
            return res;
        }
    } // class Session
}
