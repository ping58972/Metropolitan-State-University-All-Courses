package com.abc.stringcalc.dto;

import java.io.*;

/**
 * Sent from the client to the server to indicate that the client would
 * like to end its session.
 */
public class DisconnectRequest implements Serializable {
}
