package com.abc.stringcalc.client;

import java.io.*;
import java.net.*;

import com.abc.stringcalc.dto.*;
import com.abc.stringcalc.util.*;
import com.programix.io.*;

public class StringCalcClient {
    private Socket socket;
    private ObjectOutputStream oos;
    private ObjectInputStream ois;
    private Log log;

    public StringCalcClient(String hostname, int port, Log log) throws IOException {
        this.log = log;
        log.outln("Attempting to connect to " + hostname + ":" + port);
        socket = new Socket(hostname, port);
        ois = new ObjectInputStream(new BufferedInputStream(socket.getInputStream()));
        oos = new ObjectOutputStream(new BufferedOutputStream(socket.getOutputStream()));
        oos.flush();
        log.outln("created socket and object streams :) ");
    }

    private Object chat(Object req) throws IOException {
        try {
            oos.writeObject(req);
            oos.flush();
            return ois.readObject();
        } catch (ClassNotFoundException x) {
            throw new IOException(x);
        }
    }

    public void disconnect() throws IOException {
        try {
            chat(new DisconnectRequest());
        } finally {
            IOTools.closeQuietly(socket, ois, oos);
        }
    }

    public StringCalcResponse calculate(StringCalcRequest req) throws IOException {
        return (StringCalcResponse) chat(req);
    }
}
