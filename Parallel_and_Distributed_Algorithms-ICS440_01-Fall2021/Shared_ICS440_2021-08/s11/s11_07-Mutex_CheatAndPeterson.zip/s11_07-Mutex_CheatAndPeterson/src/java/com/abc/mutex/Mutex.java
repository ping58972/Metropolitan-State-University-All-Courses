package com.abc.mutex;

public interface Mutex {
    void lock();
    void unlock();
}
