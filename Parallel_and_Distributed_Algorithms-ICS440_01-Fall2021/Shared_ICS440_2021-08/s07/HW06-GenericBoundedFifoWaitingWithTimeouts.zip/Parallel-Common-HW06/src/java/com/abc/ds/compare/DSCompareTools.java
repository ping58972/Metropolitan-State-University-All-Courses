package com.abc.ds.compare;

public class DSCompareTools {
	// private, no instances
	private DSCompareTools() {
	}

	public static <T> boolean is(DSComparator<T> comparator,
							 	 DSNullOrdering nullTreatment,
							 	 DSCompareResult atLeastOneResultType,
							 	 DSCompareResult... optionalOtherResultTypes) {

		return false;
	}
}
