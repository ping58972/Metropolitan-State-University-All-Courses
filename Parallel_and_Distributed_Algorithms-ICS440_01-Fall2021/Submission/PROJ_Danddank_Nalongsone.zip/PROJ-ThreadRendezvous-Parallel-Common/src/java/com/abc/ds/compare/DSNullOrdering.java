package com.abc.ds.compare;

public enum DSNullOrdering {
	NULL_FIRST,
	NULL_LAST;
}
