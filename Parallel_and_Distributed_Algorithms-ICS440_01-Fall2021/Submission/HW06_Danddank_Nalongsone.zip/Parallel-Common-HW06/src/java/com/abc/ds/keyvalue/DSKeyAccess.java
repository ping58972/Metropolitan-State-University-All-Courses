package com.abc.ds.keyvalue;

public interface DSKeyAccess<K> {
    K getKey();
}
