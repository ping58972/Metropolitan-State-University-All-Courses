public interface ExceptionListener {
	public void exceptionOccurred(Exception x, Object source);
}
