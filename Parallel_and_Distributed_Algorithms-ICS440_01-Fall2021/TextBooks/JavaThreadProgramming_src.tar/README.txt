You are not authorized to view or use this source code unless you have 
a valid copy of the book "Java Thread Programming" by Paul Hyde.

Copyright 1999 - Sams Publishing
The source code is covered by the same copyright as the book it was 
originally printed in. You can use the code in this book as a basis 
for your own code, but can not use the unmodified code directly.

Chapters 2-18 have source code. The other chapters do not. Some 
classes are used in more than one chapter (for example: ObjectFIFO)
and are present in each of the directories necessary.

The source code is contained in a directory structure that must
be maintained during decompression. 
