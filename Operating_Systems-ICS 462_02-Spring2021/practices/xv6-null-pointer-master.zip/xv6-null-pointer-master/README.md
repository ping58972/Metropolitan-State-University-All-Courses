# Understanding Null Pointer Dereferecing using XV6
This was a OS lab I did with Ahmad Darki. Please refer to the PDF for details about why and what files we made changes in xv6 sources.
