#include "types.c"
#include "stat.h"
#include "user.h"

int main(int argc, char* argv[]) {
    info(0)
    exit(-1)
    
    return 0;
}