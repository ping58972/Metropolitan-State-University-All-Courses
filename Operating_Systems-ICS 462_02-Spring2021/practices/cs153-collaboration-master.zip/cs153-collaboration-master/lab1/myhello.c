#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char* argv[]) {
	myhello();
	exit(0);
	return 0;
}
