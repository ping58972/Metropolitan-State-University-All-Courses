#include "types.h"
#include "stat.h"
#include "user.h"

int main(int argc, char * argv[]) {
  int virtual = 0;
  int *physical;

  v2p(virtual,physical);
  exit(-1);

  return 0;
}
