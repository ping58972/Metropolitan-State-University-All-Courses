#ifndef _RAND_H_
#define _RAND_H_

void sgenrand(unsigned long);
long genrand(void);
long random_at_most(long);

#endif
