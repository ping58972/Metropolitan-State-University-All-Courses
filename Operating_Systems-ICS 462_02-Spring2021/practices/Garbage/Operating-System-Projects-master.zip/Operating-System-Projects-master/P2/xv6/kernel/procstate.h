#ifndef _PROCSTATE_H_
#define _PROCSTATE_H_

enum procstate { UNUSED, EMBRYO, SLEEPING, RUNNABLE, RUNNING, ZOMBIE };

#endif
