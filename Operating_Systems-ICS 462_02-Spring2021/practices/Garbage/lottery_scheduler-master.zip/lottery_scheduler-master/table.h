
struct table {
    int counts[5];
};