// #include "types.h"
// #include "defs.h"
// #include "memlayout.h"
// #include "x86.h"
// #include "spinlock.h"
// #include "param.h"

// int
// settickets(int number){
// 	struct proc *p;
	
// }

// int
// getpinfo(struct pstat *){
	
// }