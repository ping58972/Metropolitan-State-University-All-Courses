#include <stdio.h>

int main()
{
	_Bool hello = 0;
	hello = 100;
	hello = 0;
	if (!hello)	
	printf("%d\n", hello);
}
