#include "types.h"
#include "stat.h"
#include "user.h"
#include "fs.h"


int
main(int argc, char *argv[])
{
	char *path = (char *)((640 *1024)-(5*4096));
	mkdir(path);
		exit();
}
