#include <stdio.h>

int main(void)
{
	printf("This is a c program.\n");
	return 0;
}
