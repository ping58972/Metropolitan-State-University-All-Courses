print("Hello world!")

