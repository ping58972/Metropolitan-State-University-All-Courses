#include "types.h"
#include "user.h"


int main(){
    printf(1,"random number %d\n",random(100));
    printf(1,"random number %d\n",random(100));
    printf(1,"random number %d\n",random(100));
    printf(1,"random number %d\n",random(100));
    printf(1,"random number %d\n",random(100));

    exit();
}


