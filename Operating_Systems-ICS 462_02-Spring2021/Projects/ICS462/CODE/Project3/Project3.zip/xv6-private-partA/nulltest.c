#include "types.h"
#include "user.h"

int
main(int argc, char *argv[])
{
	int *p = 0;
	printf(1, "Testing Null pointer refenrece: %d\n", *p);
	exit();
}