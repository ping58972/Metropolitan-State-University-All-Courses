#! /bin/bash

while true; do
    ./deadlock
done


