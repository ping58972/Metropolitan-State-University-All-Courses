import boto3

s3 = boto3.client("s3", region_name="us-east-1")
bucket_name = "danddanklab7website"

file_name_1 = '/home/ec2-user/environment/DanddankLab7/lab-07-files/index.html'
response = s3.upload_file(file_name_1, bucket_name, "index.html", ExtraArgs={"ContentType":"text/html"})

file_name_2 = '/home/ec2-user/environment/DanddankLab7/lab-07-files/index.jpg'
response = s3.upload_file(file_name_2, bucket_name, "index.jpg", ExtraArgs={"ContentType":"image/jpg"})

file_name_3 = '/home/ec2-user/environment/DanddankLab7/lab-07-files/logo.jpg'
response = s3.upload_file(file_name_3, bucket_name, "logo.jpg", ExtraArgs={"ContentType":"image/jpg"})