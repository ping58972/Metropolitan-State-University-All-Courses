import boto3

s3 = boto3.resource("s3")
bucket_name = "danddanklab7website"

my_bucket = s3.Bucket(bucket_name)
my_files = my_bucket.objects.all()

for file in my_files:
    print(file)