import boto3
import json

s3 = boto3.client("s3", region_name="us-east-1")
bucket_name = "danddanklab7website"

policy_file = open("/home/ec2-user/environment/DanddankLab7/public_policy.json", "r")

s3.put_bucket_policy(
    Bucket = bucket_name,
    Policy = policy_file.read()
    )