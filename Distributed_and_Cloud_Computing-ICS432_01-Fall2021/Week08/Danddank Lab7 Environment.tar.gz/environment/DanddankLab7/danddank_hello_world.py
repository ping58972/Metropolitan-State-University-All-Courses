# import sys

# my_name = sys.argv[1]
# print("Hi There "+ my_name)

import boto3

ec2_client = boto3.client("ec2", region_name="us-east-1")
response = ec2_client.describe_instances()

for reservation in response["Reservations"]:
    for instance in reservation["Instances"]:
        print(instance["InstanceId"])
        print(instance["LaunchTime"])
        print(instance["ImageId"])
        print("============")