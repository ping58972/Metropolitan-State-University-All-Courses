import boto3

s3 = boto3.client("s3", region_name="us-east-1")
bucket_name = "danddanklab7website"

s3.create_bucket(Bucket=bucket_name)

website_configuration = {
    "ErrorDocument":{"key":"error.html"},
    "IndexDocument":{"Suffix": "index.html"}
}

s3.put_buck_website(
    Bucket = bucket_name,
    WebsiteConfiguration =website_configuration
    )