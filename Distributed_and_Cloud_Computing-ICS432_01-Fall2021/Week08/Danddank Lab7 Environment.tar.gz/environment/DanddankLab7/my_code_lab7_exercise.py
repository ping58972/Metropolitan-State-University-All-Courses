import sys
import boto3
import os

bucket_name = sys.argv[1]
print("creating you new bucket with name: "+ bucket_name)

s3 = boto3.client("s3", region_name="us-east-1")
s3.create_bucket(Bucket=bucket_name)
file_path = "/home/ec2-user/environment/DanddankLab7/reading/{0}"
arr = os.listdir("/home/ec2-user/environment/DanddankLab7/reading")
print("Upload files from AWS Cloud9 folder to Bucket S3: ")
for f in arr:
    file_name = file_path.format(f)
    type_ = f.split('.')[1]
    if(type_ == 'jpg'):
        response = s3.upload_file(file_name, bucket_name, f, ExtraArgs={"ContentType":"image/jpg"})
    elif(type_ == 'txt' or type_ == 'html'):
        response = s3.upload_file(file_name, bucket_name, f, ExtraArgs={"ContentType":"text/html"})
    print(file_name)
    
s3_res = boto3.resource("s3")
my_bucket = s3_res.Bucket(bucket_name)
my_files = my_bucket.objects.all()
print("Read files from Bucket S3:" + bucket_name)
for file in my_files:
    print(file)
print("Upload all files successfully.")
