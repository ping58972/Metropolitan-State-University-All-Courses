import boto3
import json

ec2_client = boto3.client("ec2", region_name="us-east-1")
key_pair = ec2_client.create_key_pair(KeyName="lab7keypair")

name_tag = [
        {
        "ResourceType":"instance",
        "Tags": [
                {
                    "Key": "Name",
                    "Value": "DanddankLab7Instance"
                }
            ]
        }
    ]
    
instances = ec2_client.run_instances(ImageId="ami-02e136e904f3da870", MinCount=1, Maxcount=1,InstanceType="t2.micro",
                                        Keyname="lab7keypair", TagSpecifications = name_tag)