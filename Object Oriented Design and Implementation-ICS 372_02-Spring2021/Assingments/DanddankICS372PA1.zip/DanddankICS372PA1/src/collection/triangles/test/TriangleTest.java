/**
 * @author Nalongsone Danddank
 */
package collection.triangles.test;

import static org.junit.Assert.assertNotEquals;

import org.junit.jupiter.api.Test;

import collection.triangles.Point;
import collection.triangles.Triangle;

class TriangleTest {

	@Test
	void testEqualsObject() {
		Triangle triangle1 = new Triangle(new Point(0, 0), new Point(1, 1), new Point(2, 2));
		Triangle triangle2 = new Triangle(new Point(0, 0), new Point(1, 1), new Point(2, 2));
		assertNotEquals(triangle1, triangle2);
		System.out.println(triangle1);
		System.out.println(triangle2);
	}

	@Test
	void testTrianglePointPointPoint() {

		Triangle triangle3 = new Triangle();
		System.out.println(triangle3);
		Triangle triangle4 = new Triangle(new Point(6, 6));
		System.out.println(triangle4);
	}

	@Test
	void testSetPoint() {
		Triangle triangle5 = new Triangle();
		triangle5.setPoint(1, new Point(7, 7));
		System.out.println(triangle5);
	}
}
