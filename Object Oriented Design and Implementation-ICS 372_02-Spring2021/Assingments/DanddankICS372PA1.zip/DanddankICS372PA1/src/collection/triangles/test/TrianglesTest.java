package collection.triangles.test;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

import collection.triangles.Point;
import collection.triangles.Triangle;
import collection.triangles.Triangles;

class TrianglesTest {

	@Test
	void testAddTriangle() {
		Triangles triangles = new Triangles();
		Triangle triangle = new Triangle(new Point(1, 1));

		triangles.addTriangle(new Triangle(new Point(0, 0)));
		triangles.addTriangle(triangle);
		System.out.println(triangles);
		System.out.println(triangle);
	}

	@Test
	void testDeleteTriangle() {
		Triangles triangles = new Triangles();
		Triangle triangle = new Triangle(new Point(1, 1));

		triangles.addTriangle(new Triangle(new Point(0, 0)));
		triangles.addTriangle(triangle);
		System.out.println(triangles);
		System.out.println(triangle);
		assertEquals(triangle, triangles.deleteTriangle(triangle));
		System.out.println(triangles);
	}

	@Test
	void testGetTriangle() {
		Triangles triangles = new Triangles();
		Triangle triangle = new Triangle(new Point(1, 1));

		triangles.addTriangle(new Triangle(new Point(0, 0)));
		triangles.addTriangle(triangle);
		System.out.println(triangles.getTriangle(4));
	}

}
