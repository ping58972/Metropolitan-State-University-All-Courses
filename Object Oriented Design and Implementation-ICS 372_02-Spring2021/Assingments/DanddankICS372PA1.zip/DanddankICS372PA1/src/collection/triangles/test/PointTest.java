/**
 * @author Nalongsone Danddank
 */
package collection.triangles.test;

import static org.junit.Assert.assertNotEquals;

import org.junit.jupiter.api.Test;

import collection.triangles.Point;

/**
 * @author Nalongsone Danddank
 *
 */
class PointTest {

	/**
	 * Test method for {@link collection.triangles.Point#equals(java.lang.Object)}.
	 */
	@Test
	void testEqualsObject() {
		Point point1 = new Point(0, 0);
		Point point2 = new Point(0, 0);
		assertNotEquals(point1.getId(), point2.getId());
		System.out.println(point1);
		System.out.println(point2);
//		fail("Not yet implemented");
	}

}
