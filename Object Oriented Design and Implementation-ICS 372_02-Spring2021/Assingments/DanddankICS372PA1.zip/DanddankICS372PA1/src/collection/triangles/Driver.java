/**
 * This class for testing each method that implement in those class.
 * @author Nalongsone Danddank
 */
package collection.triangles;

public class Driver {

	public static void main(String[] args) {
		// Create nine Point objects
		Point point0 = new Point(0, 0);
		Point point1 = new Point(1, 1);
		Point point2 = new Point(2, 2);
		Point point3 = new Point(3, 3);
		Point point4 = new Point(4, 4);
		Point point5 = new Point(5, 5);
		Point point6 = new Point(6, 6);
		Point point7 = new Point(7, 7);
		Point point8 = new Point(8, 8);
		// Test Point class
		System.out.println(point0.toString());
		System.out.println("Result should be False == " + point0.equals(point1));

		// Create three Triangle object.
		Triangle triangle0 = new Triangle(point0, point1, point2);
		Triangle triangle1 = new Triangle(point3, point4, point5);

		// Test Triangle toString:
		System.out.println(triangle0.toString());
		System.out.println(triangle1);

		// test setPoint method.
		Triangle triangle2 = new Triangle(point6);
		triangle2.setPoint(1, point7);
		triangle2.setPoint(2, point8);
		System.out.println(triangle2);
		// test equals method.
		System.out.println("Result should be False == " + triangle2.equals(triangle0));

		// Create Triangles object to list the Triangle.
		Triangles triangles = new Triangles();

		// test addTriangle method
		triangles.addTriangle(triangle0);
		triangles.addTriangle(triangle1);
		triangles.addTriangle(triangle2);
		System.out.println(triangles);

		// test deleteTriangle method.
		triangles.deleteTriangle(triangle0);
		System.out.println(triangles);

		// test getTriangle method.
		System.out.println("Expect object " + triangle1 + " then the return object should be same as "
				+ triangles.getTriangle(triangle1.getId()));

	}

}
