/**
 * this class represents a point on a plane.
 * 
 * @author Nalongsone Danddank
 * @Copyright (c) 2021
 *
 */
public class Point {
	// x, an integer that stores the x-coordinate of a point on a plane.
	private int x;
	// y, an integer that stores the y-coordinate of the same point on a plane.
	private int y;
	// id, an integer that uniquely identifies the Point object.
	private int id;
	// A static idCounter to generate the value to be stored in id.
	static int idCounter = 0;

	/**
	 * @param x
	 * @param y
	 * @param id
	 */
	public Point(int x, int y) {
		this.x = x;
		this.y = y;
		// Storing unique value to id and increase by 1.
		this.id = idCounter++;
	}

	public int getX() {
		return x;
	}

	public int getY() {
		return y;
	}

	public int getId() {
		return id;
	}

	@Override
	public String toString() {
		return "Point" + id + " [pointId=" + id + ", x=" + x + ", y=" + y + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result + x;
		result = prime * result + y;
		return result;
	}

	// Two Point objects are equal only if they have the same id.
	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		if (object == null) {
			return false;
		}
		if (getClass() != object.getClass()) {
			return false;
		}
		Point other = (Point) object;
		if (id != other.id) {
			return false;
		}
		return true;
	}

}
