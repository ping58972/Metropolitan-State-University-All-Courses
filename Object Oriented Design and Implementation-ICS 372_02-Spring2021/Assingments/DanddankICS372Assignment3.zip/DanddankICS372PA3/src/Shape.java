/**
 * This interface use for implement the Adapter pattern. for extend by
 * FilledShape interface and implement by Rectangle and Square class to display
 * instance of the class.
 * 
 * @author Nalongsone Danddank
 * @Copyright (c) 2021
 *
 */
public interface Shape {
	public void display();
}
