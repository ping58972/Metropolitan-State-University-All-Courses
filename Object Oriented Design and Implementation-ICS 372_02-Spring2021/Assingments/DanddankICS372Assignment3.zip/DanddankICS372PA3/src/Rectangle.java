/**
 * This class uses Adapter pattern, object adapter by instance Polygon object
 * Adaptee and implement FilledShape interface for set a color and display the
 * rectangle and color.
 * 
 * @author Nalongsone Danddank
 * @Copyright (c) 2021
 *
 */
public class Rectangle implements FilledShape {

	// implement object adapter.
	private Polygon polygon;
	private int red;
	private int green;
	private int blue;

	/**
	 * Constructor accept two points, if the two Point objects do not represent a
	 * rectangle with non-zero area, will throw a Exception.
	 * 
	 * @params point1 - Point; point2 - Point
	 * @throws Exception - if the two Point objects do not represent a rectangle
	 *                   with non-zero area
	 */
	public Rectangle(Point point1, Point point2) throws Exception {
		if (point1.getX() == point2.getX() || point1.getY() == point2.getY()) {
			throw new Exception("the two Point objects do not represent a rectangle with non-zero area");
		}
		this.generateRactanglePolygon(point1, point2);
		this.setColor(0, 0, 0);
	}

	/**
	 * Accept two points to generate a Ractangle by using polygon object.
	 * 
	 * @params point1 - Point; point2 - Point
	 */
	private void generateRactanglePolygon(Point point1, Point point3) {
		this.polygon = new Polygon();
		this.polygon.addPoint(point1);
		this.polygon.addPoint(new Point(point3.getX(), point1.getY()));
		this.polygon.addPoint(point3);
		this.polygon.addPoint(new Point(point1.getX(), point3.getY()));
		this.polygon.end();
	}

	@Override
	public void display() {
		System.out.println("Rectangle " + this.toString());
	}

	/**
	 * set color by set 3 integers: red, green, and blue, to the instance. But only
	 * in the range of [0 -> 255].
	 * 
	 * @params: red - int; green - int; blue - int.
	 */
	@Override
	public void setColor(int red, int green, int blue) {
		if (red < 0 || red > 255 || green < 0 || green > 255 || blue < 0 || blue > 255) {
			return;
		} else {
			this.red = red;
			this.green = green;
			this.blue = blue;
		}
	}

	@Override
	public String toString() {
		return "" + this.polygon + "filled in " + "(red=" + red + ", green=" + green + ", blue=" + blue + ")";
	}

}
