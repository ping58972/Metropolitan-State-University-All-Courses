/**
 * This interface use for impliment the Adapter pattern. for implement by
 * Rectangle and Square class to fill shape and set color for them.
 * 
 * @author Nalongsone Danddank
 * @Copyright (c) 2021
 *
 */
public interface FilledShape extends Shape {
	public void setColor(int red, int green, int blue);
}
