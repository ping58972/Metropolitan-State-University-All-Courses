/**
 * This class uses Adapter pattern, class adapter by extends Rectangle Adaptee
 * and implement FilledShape interface for set a color.
 * 
 * @author Nalongsone Danddank
 * @Copyright (c) 2021
 *
 */
public class Square extends Rectangle implements FilledShape {

	/**
	 * 
	 */
	public Square(Point point1, Point point2) throws Exception {
		super(point1, point2);
		if (Math.abs(point1.getX() - point2.getX()) != Math.abs(point1.getY() - point2.getY())) {
			throw new Exception("These Two points can not build a Square!");
		}
	}

	@Override
	public void display() {
		System.out.println("Square " + super.toString());
	}

}
