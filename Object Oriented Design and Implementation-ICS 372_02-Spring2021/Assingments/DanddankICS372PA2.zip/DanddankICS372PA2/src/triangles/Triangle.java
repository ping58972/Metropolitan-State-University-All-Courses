package triangles;

import java.util.Arrays;

/**
 * This class for implement the triangle
 * 
 * @author Nalongsone Danddank
 *
 */
public class Triangle {

	// An array of Point objects of length 3.
	private Point[] points = new Point[3];
	// id, an integer that uniquely identifies the Triangle object.
	private int id;
	// A static idCounter to generate the value for id.
	static int idCounter = 0;

	public Triangle() {
		this(null, null, null);
	}

	public Triangle(Point point) {
		this(point, null, null);
	}

	/**
	 * @param points
	 * @param id
	 */
	public Triangle(Point point0, Point point1, Point point2) {
		this.points[0] = point0;
		this.points[1] = point1;
		this.points[2] = point2;

		// Storing unique value to id and increase by 1.
		this.id = idCounter++;
	}

	/**
	 * @param index
	 * @param point
	 */
	public void setPoint(int index, Point point) {
		// If index is anything other than 0, 1, or 2, the method does not store
		if (index < 0 || index > points.length) {
			System.out.println("Can't store! Index is not in the points array.");
			return;
		}
		// Prevent null Exception
		if (point == null) {
			System.out.println("Can't store! the object is null.");
			return;
		}
		this.points[index] = point;
	}

	@Override
	public String toString() {
		return "Triangle" + id + " [ triangleId=" + id + " pointArray=" + Arrays.toString(points) + "]";
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result + Arrays.hashCode(points);
		return result;
	}

	// Two Triangle objects are equal only if they have the same id.
	@Override
	public boolean equals(Object object) {
		if (this == object) {
			return true;
		}
		if (object == null) {
			return false;
		}
		if (getClass() != object.getClass()) {
			return false;
		}
		Triangle other = (Triangle) object;
		if (id != other.id) {
			return false;
		}
		return true;
	}

	public int getId() {
		return id;
	}

	public Point[] getPoints() {
		return points;
	}

}
