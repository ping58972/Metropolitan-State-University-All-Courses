package triangles;

/**
 * This is a collection class that uses java.util.LinkedList to store Triangle objects.
 * @author Nalongsone Danddank
 */

import java.util.LinkedList;
import java.util.List;

public class Triangles {

	// triangles � a linked list of Triangle objects
	private List<Triangle> triangles = new LinkedList<Triangle>();

	/**
	 * adds the Triangle object to the triangles list
	 * 
	 * @param triangle - the object to be add
	 */
	public void addTriangle(Triangle triangle) {
		// prevent null Exception.
		if (triangle == null) {
			System.out.println("Triangle Object is null!");
			return;
		}
		this.triangles.add(triangle);

	}

	/**
	 * Delete the Triangle object from the triangles list
	 * 
	 * @param triangle - the object to be deleted
	 * @return triangle - the object which deleted
	 */
	public Triangle deleteTriangle(Triangle triangle) {
		// prevent null Exception.
		if (triangle == null) {
			System.out.println("Triangle Object is null!");
			return null;
		}
		// if the object contains in the list return it.
		if (this.triangles.remove(triangle)) {
			return triangle;
		}

		return null;
	}

	/**
	 * Get the Triangle object from the triangles list
	 * 
	 * @param id - the id of triangle that should in the list
	 * @return triangle - the object which getting
	 */
	public Triangle getTriangle(int id) {
		for (Triangle triangle : this.triangles) {
			// Looking for triangle in the list
			// if the triangle object of id is equal, return it.
			if (triangle.getId() == id) {
				return triangle;
			}
		}
		return null;
	}

	@Override
	public String toString() {
		return "TrianglesList " + triangles;
	}

}

