package application;

/**
 * This class for implement the DrawTriangleGUI of drawing triangle.
 * 
 * @author Nalongsone Danddank
 *
 */

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import triangles.Point;
import triangles.Triangle;

public class DrawTriangleGUI extends Application implements EventHandler<ActionEvent> {

	private Label xLabel = new Label("x");
	private Label yLabel = new Label("y");
	private Label point1Label = new Label("Point 1	");
	private Label point2Label = new Label("Point 2	");
	private Label point3Label = new Label("Point 3	");
	private TextField x1Field = new TextField("40");
	private TextField x2Field = new TextField("80");
	private TextField x3Field = new TextField("20");
	private TextField y1Field = new TextField("100");
	private TextField y2Field = new TextField("200");
	private TextField y3Field = new TextField("150");
	private Button createButton = new Button("create");
	private Button endButton = new Button("end");
	private Canvas canvas = new Canvas(400, 400);
	private GraphicsContext gContext = canvas.getGraphicsContext2D();

	@Override
	public void start(Stage primaryStage) throws Exception {
		GridPane pane = new GridPane();
		pane.add(canvas, 0, 0);
		GridPane inputPane = new GridPane();
		inputPane.add(xLabel, 1, 0);
		inputPane.add(yLabel, 2, 0);
		inputPane.add(point1Label, 0, 1);
		inputPane.add(point2Label, 0, 2);
		inputPane.add(point3Label, 0, 3);
		inputPane.add(x1Field, 1, 1);
		inputPane.add(x2Field, 1, 2);
		inputPane.add(x3Field, 1, 3);
		inputPane.add(y1Field, 2, 1);
		inputPane.add(y2Field, 2, 2);
		inputPane.add(y3Field, 2, 3);
		GridPane buttonPane = new GridPane();

		buttonPane.add(createButton, 0, 0);
		buttonPane.add(endButton, 1, 0);
		pane.add(inputPane, 0, 1);
		pane.add(buttonPane, 0, 2);
		Scene scene = new Scene(pane);

		// set title name for window.
		primaryStage.setTitle("Assignment 2");
		primaryStage.setScene(scene);
		createButton.setOnAction(this);
		endButton.setOnAction(this);
		primaryStage.show();
	}

	public static void main(String[] args) {
		Application.launch(null);
	}

	@Override
	public void handle(ActionEvent event) {
		if (event.getSource() == createButton) {
			// Draw the triangle when user click button.
			createTriangle();
		} else if (event.getSource() == endButton) {
			// Close the Application when click the end button.
			final Node source = (Node) event.getSource();
			final Stage stage = (Stage) source.getScene().getWindow();
			stage.close();
		}
	}

	/*
	 * to create triangle line from input fields.
	 */
	private void createTriangle() {
		// create 3 points from input.
		Point point1 = new Point(Integer.parseInt(x1Field.getText()), Integer.parseInt(y1Field.getText()));
		Point point2 = new Point(Integer.parseInt(x2Field.getText()), Integer.parseInt(y2Field.getText()));
		Point point3 = new Point(Integer.parseInt(x3Field.getText()), Integer.parseInt(y3Field.getText()));

		// create triangle by these 3 points.
		Triangle triangle = new Triangle(point1, point2, point3);
		Point[] points = triangle.getPoints();

		// Draw the triangle from the 3 points.
		gContext.strokeLine(points[0].getX(), points[0].getY(), points[1].getX(), points[1].getY());
		gContext.strokeLine(points[1].getX(), points[1].getY(), points[2].getX(), points[2].getY());
		gContext.strokeLine(points[2].getX(), points[2].getY(), points[0].getX(), points[0].getY());
	}

}