import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class S2 extends Stage implements EventHandler<ActionEvent> {
	private Button b1 = new Button("try");
	private TextField t1 = new TextField();
	Canvas canvas = new Canvas(800, 400);

	public S2() {
		VBox box = new VBox();
		box.getChildren().add(b1);
		box.getChildren().add(t1);
		box.getChildren().add(canvas);
		Scene s = new Scene(box);
		b1.setOnAction(this);
		this.setScene(s);
		show();
	}

	@Override
	public void handle(ActionEvent event) {
		t1.setText("HAHA");
		GraphicsContext gc = canvas.getGraphicsContext2D();
		gc.strokeLine(20, 30, 40, 50);
	}
}
