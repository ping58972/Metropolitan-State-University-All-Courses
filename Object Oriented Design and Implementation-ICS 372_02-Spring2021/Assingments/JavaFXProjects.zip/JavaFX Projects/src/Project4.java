import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Project4 extends Application implements EventHandler<ActionEvent> {
	private Button okButton = new Button("OK");
	private TextField field = new TextField();
	private TextArea textArea = new TextArea();
	private int counter = 1;

	@Override
	public void start(Stage primaryStage) throws Exception {
		GridPane pane = new GridPane();
		pane.add(textArea, 0, 0);
		pane.add(field, 0, 1);
		pane.add(okButton, 0, 2);
		Scene scene = new Scene(pane);
		primaryStage.setTitle("Project 4");
		primaryStage.setScene(scene);
		okButton.setOnAction(this);
		primaryStage.show();
	}

	public static void main(String[] args) {
		Application.launch(null);
	}

	@Override
	public void handle(ActionEvent event) {
		textArea.appendText(field.getText() + "\n");
	}

}
