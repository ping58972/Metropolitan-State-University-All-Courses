import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

public class Project6 extends Application implements EventHandler<ActionEvent> {
	private Button rectangleButton = new Button("Rectangle");
	private Button circleButton = new Button("Circle");
	private Button greenButton = new Button("Green");
	private Button redButton = new Button("Red");
	private Color color = Color.RED;
	private int shape = RECTANGLE;
	private static final int RECTANGLE = 1;
	private static final int CIRCLE = 2;
	Pane pane = new Pane();
	GridPane bigPane = new GridPane();

	@Override
	public void start(Stage primaryStage) throws Exception {
		pane.setPrefWidth(400);
		pane.setPrefHeight(400);
		bigPane.add(pane, 0, 0);
		GridPane buttonPane = new GridPane();
		buttonPane.add(rectangleButton, 0, 0);
		buttonPane.add(circleButton, 1, 0);
		buttonPane.add(greenButton, 0, 1);
		buttonPane.add(redButton, 1, 1);
		bigPane.add(buttonPane, 0, 1);
		Scene scene = new Scene(bigPane);
		primaryStage.setTitle("Project 6");
		primaryStage.setScene(scene);
		rectangleButton.setOnAction(this);
		greenButton.setOnAction(this);
		circleButton.setOnAction(this);
		redButton.setOnAction(this);
		pane.setOnMouseClicked(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				if (shape == CIRCLE) {
					Circle circle = new Circle();
					circle.setCenterX(event.getSceneX());
					circle.setCenterY(event.getSceneY());
					circle.setFill(color);
					circle.setRadius(50);
					pane.getChildren().add(circle);

				} else if (shape == RECTANGLE) {
					Rectangle rectangle = new Rectangle();
					rectangle.setX(event.getSceneX());
					rectangle.setY(event.getSceneY());
					rectangle.setWidth(80);
					rectangle.setHeight(40);
					rectangle.setFill(color);
					pane.getChildren().add(rectangle);
				}
			}
		});
		primaryStage.show();

	}

	public static void main(String[] args) {
		Application.launch(null);
	}

	@Override
	public void handle(ActionEvent event) {
		if (event.getSource() == redButton) {
			color = Color.RED;
		} else if (event.getSource() == greenButton) {
			color = Color.GREEN;
		} else if (event.getSource() == rectangleButton) {
			shape = RECTANGLE;
		} else if (event.getSource() == circleButton) {
			shape = CIRCLE;
		}
	}

}
