import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Project2 extends Application {
	private Button okButton = new Button("OK");
	private TextField field = new TextField();

	@Override
	public void start(Stage primaryStage) throws Exception {
		GridPane pane = new GridPane();
		pane.add(field, 0, 0);
		pane.add(okButton, 0, 1);
		Scene scene = new Scene(pane);
		primaryStage.setTitle("Project 2");
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	public static void main(String[] args) {
		Application.launch(null);
	}

}
