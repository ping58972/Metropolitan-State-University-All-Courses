/**
 * Implements the functionality for a room in a hotel. The field
 * totalRentPerNight stores the total rent for a single night in this room for
 * the specified number of guests.
 * 
 * @author mh6624pa
 *
 */
public abstract class Room {
    private int roomNumber;
    private double basicChargePerNight;
    private double extraChargePerPersonPerNight;
    private double totalRentPerNight;

    /**
     * Store the room number, type, the basic charge, and the extra charge per
     * person per night.
     * 
     * @param roomNumber                   the room number
     * @param basicChargePerNight          charge per night if there are no extra
     *                                     occupants
     * @param extraChargePerPersonPerNight charge for each additional person per
     *                                     night
     */
    public Room(int roomNumber, double basicChargePerNight, double extraChargePerPersonPerNight) {
        this.roomNumber = roomNumber;
        this.basicChargePerNight = basicChargePerNight;
        this.extraChargePerPersonPerNight = extraChargePerPersonPerNight;
    }

    /**
     * Computes the total charge per night of occupancy for this room for the given
     * number of guests.
     * 
     * @param numberOfGuests number of guests
     * @throws Exception thrown if number of guests exceeds a certain number, which
     *                   is dependent on the room type
     */
    public abstract void computeTotalChargePerNight(int numberOfGuests) throws Exception;

    public int getRoomNumber() {
        return roomNumber;
    }

    public double getBasicChargePerNight() {
        return basicChargePerNight;
    }

    public double getExtraChargePerPersonPerNight() {
        return extraChargePerPersonPerNight;
    }

    public double getTotalRentPerNight() {
        return totalRentPerNight;
    }

    public void setTotalRentPerNight(double charge) {
        totalRentPerNight = charge;
    }

}
