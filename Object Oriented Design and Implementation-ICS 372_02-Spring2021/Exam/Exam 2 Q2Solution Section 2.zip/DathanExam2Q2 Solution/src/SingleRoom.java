/**
 * Implements the functionality for a room in a hotel. The field
 * totalRentPerNight stores the total rent for a single night in this room for
 * the specified number of guests.
 * 
 * @author mh6624pa
 *
 */
public class SingleRoom extends Room {
    /**
     * Store the room number, type, the basic charge, and the extra charge per
     * person per night.
     * 
     * @param roomNumber                   the room number
     * @param type                         single, double, or suite
     * @param basicChargePerNight          charge per night if there are no extra
     *                                     occupants
     * @param extraChargePerPersonPerNight charge for each additional person per
     *                                     night
     */
    public SingleRoom(int roomNumber, double basicChargePerNight, double extraChargePerPersonPerNight) {
        super(roomNumber, basicChargePerNight, extraChargePerPersonPerNight);
    }

    /**
     * Computes the total charge per night of occupancy for this room for the given
     * number of guests.
     * 
     * @param numberOfGuests number of guests
     * @throws Exception thrown if number of guests exceeds a certain number, which
     *                   is dependent on the room type
     */
    public void computeTotalChargePerNight(int numberOfGuests) throws Exception {
        if (numberOfGuests < 1 || numberOfGuests > 2) {
            throw new Exception("Invalid number of guests");
        }
        setTotalRentPerNight(getBasicChargePerNight() + (numberOfGuests - 1) * getExtraChargePerPersonPerNight());

    }

    /**
     * A very elementary test of the functionality
     * 
     * @param args not used
     */
    public static void main(String[] args) {
        SingleRoom singleRoom = new SingleRoom(1, 50.0, 10.0);
        try {
            singleRoom.computeTotalChargePerNight(2);
            assert singleRoom.getTotalRentPerNight() == 60.0;

        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            singleRoom.computeTotalChargePerNight(1);
            assert singleRoom.getTotalRentPerNight() == 50.0;
        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            singleRoom.computeTotalChargePerNight(3);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
