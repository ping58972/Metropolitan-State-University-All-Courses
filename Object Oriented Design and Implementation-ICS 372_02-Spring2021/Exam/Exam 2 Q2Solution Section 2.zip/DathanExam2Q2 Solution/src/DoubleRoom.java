/**
 * Implements the functionality for a room in a hotel. The field
 * totalRentPerNight stores the total rent for a single night in this room for
 * the specified number of guests.
 * 
 * @author mh6624pa
 *
 */
public class DoubleRoom extends Room {

    /**
     * Store the room number, type, the basic charge, and the extra charge per
     * person per night.
     * 
     * @param roomNumber                   the room number
     * @param basicChargePerNight          charge per night if there are no extra
     *                                     occupants
     * @param extraChargePerPersonPerNight charge for each additional person per
     *                                     night
     */
    public DoubleRoom(int roomNumber, double basicChargePerNight, double extraChargePerPersonPerNight) {
        super(roomNumber, basicChargePerNight, extraChargePerPersonPerNight);
    }

    /**
     * Computes the total charge per night of occupancy for this room for the given
     * number of guests.
     * 
     * @param numberOfGuests number of guests
     * @throws Exception thrown if number of guests exceeds a certain number, which
     *                   is dependent on the room type
     */
    public void computeTotalChargePerNight(int numberOfGuests) throws Exception {
        if (numberOfGuests < 1 || numberOfGuests > 4) {
            throw new Exception("Invalid number of guests");
        }
        setTotalRentPerNight(
                getBasicChargePerNight() + Math.max(0, (numberOfGuests - 2)) * getExtraChargePerPersonPerNight());
    }

    /**
     * A very elementary test of the functionality
     * 
     * @param args not used
     */
    public static void main(String[] args) {
        DoubleRoom doubleRoom = new DoubleRoom(2, 90.0, 20.0);

        try {
            doubleRoom.computeTotalChargePerNight(4);
            assert doubleRoom.getTotalRentPerNight() == 130.0;
        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            doubleRoom.computeTotalChargePerNight(2);
            assert doubleRoom.getTotalRentPerNight() == 90.0;
        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            doubleRoom.computeTotalChargePerNight(5);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
