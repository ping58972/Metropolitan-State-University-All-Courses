/**
 * Implements the functionality for a room in a hotel. The field
 * totalRentPerNight stores the total rent for a single night in this room for
 * the specified number of guests.
 * 
 * @author mh6624pa
 *
 */
public class Suite extends Room {
    /**
     * Store the room number, type, the basic charge, and the extra charge per
     * person per night.
     * 
     * @param roomNumber                   the room number
     * @param basicChargePerNight          charge per night if there are no extra
     *                                     occupants
     * @param extraChargePerPersonPerNight charge for each additional person per
     *                                     night
     */
    public Suite(int roomNumber, double basicChargePerNight, double extraChargePerPersonPerNight) {
        super(roomNumber, basicChargePerNight, extraChargePerPersonPerNight);
    }

    /**
     * Computes the total charge per night of occupancy for this room for the given
     * number of guests.
     * 
     * @param numberOfGuests number of guests
     * @throws Exception thrown if number of guests exceeds a certain number, which
     *                   is dependent on the room type
     */
    public void computeTotalChargePerNight(int numberOfGuests) throws Exception {
        if (numberOfGuests < 1 || numberOfGuests > 8) {
            throw new Exception("Invalid number of guests");
        }
        setTotalRentPerNight(
                getBasicChargePerNight() + Math.max(0, (numberOfGuests - 4)) * getExtraChargePerPersonPerNight());
    }

    /**
     * A very elementary test of the functionality
     * 
     * @param args not used
     */
    public static void main(String[] args) {
        Suite suite = new Suite(3, 200.0, 50.0);
        try {
            suite.computeTotalChargePerNight(4);
            assert suite.getTotalRentPerNight() == 200.0;
        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            suite.computeTotalChargePerNight(8);
            assert suite.getTotalRentPerNight() == 400.0;
        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            suite.computeTotalChargePerNight(9);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
