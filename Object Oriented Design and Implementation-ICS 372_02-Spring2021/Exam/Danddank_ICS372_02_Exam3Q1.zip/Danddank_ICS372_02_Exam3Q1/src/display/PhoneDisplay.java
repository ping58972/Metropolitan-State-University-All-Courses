package display;

public interface PhoneDisplay {

	public void showOff();

	public void showDialTone();

	public void showDialing();

	public void showBusy();

	public void showConnected();

	public String getPhoneNumberField();

	public void showWarming();
}