package states;

import events.BusySignalEvent;
import events.ConnectedSignalEvent;
import events.DialingEvent;
import events.HangUpEvent;
import events.PickUpEvent;

public class DialToneState extends PhoneState {
	private static DialToneState instance;

	private DialToneState() {
		instance = this;
	}

	public static DialToneState instance() {
		if (instance == null) {
			instance = new DialToneState();
		}
		return instance;
	}

	@Override
	public void enter() {
		PhoneContext.instance().showDialTone();
	}

	@Override
	public void leave() {
	}

	@Override
	public void handleEvent(PickUpEvent event) {
		PhoneContext.instance().changeState(DialToneState.instance());

	}

	@Override
	public void handleEvent(DialingEvent event) {
		if (PhoneContext.instance().isPhoneNumberFieldWork()) {
			PhoneContext.instance().changeState(DialingState.instance());
		} else {
			System.out.println("Please Enter only digit number.");
			PhoneContext.instance().showWarming();
			PhoneContext.instance().changeState(DialToneState.instance());
		}

	}

	@Override
	public void handleEvent(HangUpEvent event) {
		PhoneContext.instance().changeState(OffState.instance());
	}

	@Override
	public void handleEvent(BusySignalEvent event) {
		PhoneContext.instance().changeState(DialToneState.instance());
	}

	@Override
	public void handleEvent(ConnectedSignalEvent event) {
		PhoneContext.instance().changeState(DialToneState.instance());
	}

}