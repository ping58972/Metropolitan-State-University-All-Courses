package states;

import events.BusySignalEvent;
import events.ConnectedSignalEvent;
import events.DialingEvent;
import events.HangUpEvent;
import events.PickUpEvent;

public class BusyState extends PhoneState {
	private static BusyState instance;

	private BusyState() {
	}

	public static BusyState instance() {
		if (instance == null) {
			instance = new BusyState();
		}
		return instance;
	}

	@Override
	public void enter() {
		PhoneContext.instance().showBusy();
	}

	@Override
	public void leave() {
	}

	@Override
	public void handleEvent(PickUpEvent event) {
		PhoneContext.instance().changeState(DialToneState.instance());

	}

	@Override
	public void handleEvent(DialingEvent event) {
		PhoneContext.instance().changeState(BusyState.instance());
	}

	@Override
	public void handleEvent(HangUpEvent event) {
		PhoneContext.instance().changeState(OffState.instance());
	}

	@Override
	public void handleEvent(BusySignalEvent event) {
		PhoneContext.instance().changeState(BusyState.instance());
	}

	@Override
	public void handleEvent(ConnectedSignalEvent event) {
		PhoneContext.instance().changeState(BusyState.instance());
	}
}