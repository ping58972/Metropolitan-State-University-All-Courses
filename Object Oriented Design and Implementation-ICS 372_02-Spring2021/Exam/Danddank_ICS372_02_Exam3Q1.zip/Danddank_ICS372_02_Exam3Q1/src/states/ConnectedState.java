package states;

import events.BusySignalEvent;
import events.ConnectedSignalEvent;
import events.DialingEvent;
import events.HangUpEvent;
import events.PickUpEvent;

public class ConnectedState extends PhoneState {
	private static ConnectedState connectedState;

	private ConnectedState() {

	}

	public static ConnectedState instance() {
		if (connectedState == null) {
			connectedState = new ConnectedState();
		}
		return connectedState;
	}

	public void enter() {
		PhoneContext.instance().showConnected();
	}

	public void leave() {

	}

	@Override
	public void handleEvent(PickUpEvent event) {
		PhoneContext.instance().changeState(ConnectedState.instance());

	}

	@Override
	public void handleEvent(DialingEvent event) {
		PhoneContext.instance().changeState(ConnectedState.instance());
	}

	@Override
	public void handleEvent(HangUpEvent event) {
		PhoneContext.instance().changeState(OffState.instance());
	}

	@Override
	public void handleEvent(BusySignalEvent event) {
		PhoneContext.instance().changeState(ConnectedState.instance());
	}

	@Override
	public void handleEvent(ConnectedSignalEvent event) {
		PhoneContext.instance().changeState(ConnectedState.instance());
	}

}