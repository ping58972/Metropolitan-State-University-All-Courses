package states;

import events.BusySignalEvent;
import events.ConnectedSignalEvent;
import events.DialingEvent;
import events.HangUpEvent;
import events.PickUpEvent;

public class OffState extends PhoneState {
	private static OffState instance;

	private OffState() {
	}

	public static OffState instance() {
		if (instance == null) {
			instance = new OffState();
		}
		return instance;
	}

	@Override
	public void enter() {
		PhoneContext.instance().showOff();
	}

	@Override
	public void leave() {
	}

	@Override
	public void handleEvent(PickUpEvent event) {
		PhoneContext.instance().changeState(DialToneState.instance());
	}

	@Override
	public void handleEvent(DialingEvent event) {
		PhoneContext.instance().changeState(OffState.instance());
	}

	@Override
	public void handleEvent(HangUpEvent event) {
		PhoneContext.instance().changeState(OffState.instance());
	}

	@Override
	public void handleEvent(BusySignalEvent event) {
		PhoneContext.instance().changeState(OffState.instance());
	}

	@Override
	public void handleEvent(ConnectedSignalEvent event) {
		PhoneContext.instance().changeState(OffState.instance());
	}
}