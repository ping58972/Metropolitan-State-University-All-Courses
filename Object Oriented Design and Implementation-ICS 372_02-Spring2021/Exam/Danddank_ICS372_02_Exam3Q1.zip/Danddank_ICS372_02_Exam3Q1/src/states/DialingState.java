package states;

import events.BusySignalEvent;
import events.ConnectedSignalEvent;
import events.DialingEvent;
import events.HangUpEvent;
import events.PickUpEvent;

public class DialingState extends PhoneState {
	private static DialingState instance;

	private DialingState() {
	}

	public static DialingState instance() {
		if (instance == null) {
			instance = new DialingState();
		}
		return instance;
	}

	@Override
	public void enter() {
		PhoneContext.instance().showDialing();
	}

	@Override
	public void leave() {
	}

	@Override
	public void handleEvent(PickUpEvent event) {
		PhoneContext.instance().changeState(DialingState.instance());

	}

	@Override
	public void handleEvent(DialingEvent event) {
		PhoneContext.instance().changeState(DialingState.instance());
	}

	@Override
	public void handleEvent(HangUpEvent event) {
		PhoneContext.instance().changeState(OffState.instance());
	}

	@Override
	public void handleEvent(BusySignalEvent event) {
		PhoneContext.instance().changeState(BusyState.instance());
	}

	@Override
	public void handleEvent(ConnectedSignalEvent event) {
		PhoneContext.instance().changeState(ConnectedState.instance());
	}

}