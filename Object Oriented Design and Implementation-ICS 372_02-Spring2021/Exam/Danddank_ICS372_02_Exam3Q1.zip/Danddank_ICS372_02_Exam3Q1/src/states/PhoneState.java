package states;

import events.BusySignalEvent;
import events.ConnectedSignalEvent;
import events.DialingEvent;
import events.HangUpEvent;
import events.PickUpEvent;

public abstract class PhoneState {
    public abstract void enter();

    public abstract void leave();

    public void handleEvent(ConnectedSignalEvent event) {
    }

    public void handleEvent(BusySignalEvent event) {
    }

    public void handleEvent(DialingEvent event) {
    }

    public void handleEvent(HangUpEvent event) {

    }

    public void handleEvent(PickUpEvent event) {

    }
}