package events;

public class PickUpEvent extends PhoneEvent {
    private static PickUpEvent instance;

    private PickUpEvent() {

    }

    public static PickUpEvent instance() {
        if (instance == null) {
            instance = new PickUpEvent();
        }
        return instance;
    }
}