package events;

public class DialingEvent extends PhoneEvent {
    private static DialingEvent instance;

    private DialingEvent() {

    }

    public static DialingEvent instance() {
        if (instance == null) {
            instance = new DialingEvent();
        }
        return instance;
    }
}