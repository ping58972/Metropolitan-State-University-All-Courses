package events;

public class BusySignalEvent extends PhoneEvent {
    private static BusySignalEvent instance;

    private BusySignalEvent() {

    }

    public static BusySignalEvent instance() {
        if (instance == null) {
            instance = new BusySignalEvent();
        }
        return instance;
    }
}