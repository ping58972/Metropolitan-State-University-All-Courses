package events;

public class ConnectedSignalEvent extends PhoneEvent {
    private static ConnectedSignalEvent instance;

    private ConnectedSignalEvent() {

    }

    public static ConnectedSignalEvent instance() {
        if (instance == null) {
            instance = new ConnectedSignalEvent();
        }
        return instance;
    }
}