package buttons;

import events.BusySignalEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import states.PhoneContext;

public class BusySignalButton extends GUIButton implements EventHandler<ActionEvent> {

    public BusySignalButton(String string) {
        super(string);
    }

    @Override
    public void handle(ActionEvent event) {
        PhoneContext.instance().handleEvent(BusySignalEvent.instance());
    }
}