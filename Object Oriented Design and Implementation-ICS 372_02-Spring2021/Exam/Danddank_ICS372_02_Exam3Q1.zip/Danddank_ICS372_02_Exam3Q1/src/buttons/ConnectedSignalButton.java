package buttons;

import events.ConnectedSignalEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import states.PhoneContext;

public class ConnectedSignalButton extends GUIButton implements EventHandler<ActionEvent> {

    public ConnectedSignalButton(String string) {
        super(string);
    }

    @Override
    public void handle(ActionEvent event) {
        PhoneContext.instance().handleEvent(ConnectedSignalEvent.instance());
    }
}