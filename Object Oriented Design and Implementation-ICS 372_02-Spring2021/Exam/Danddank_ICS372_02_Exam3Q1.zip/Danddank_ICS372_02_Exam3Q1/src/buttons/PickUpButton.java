package buttons;

import events.PickUpEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import states.PhoneContext;

public class PickUpButton extends GUIButton implements EventHandler<ActionEvent> {

    public PickUpButton(String string) {
        super(string);
    }

    @Override
    public void handle(ActionEvent event) {
        System.out.println("event " + event);
        PhoneContext.instance().handleEvent(PickUpEvent.instance());
    }
}