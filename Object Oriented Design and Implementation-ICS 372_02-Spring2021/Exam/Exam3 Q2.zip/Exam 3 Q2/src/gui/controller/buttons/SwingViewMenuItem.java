package gui.controller.buttons;

import gui.view.views.SwingView;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.control.MenuItem;

/**
 * Menu item for creating a swing view
 * 
 * @author Brahma Dathan
 *
 */
public class SwingViewMenuItem extends MenuItem {
    /**
     * The constructor ensures that, when the menu item is clicked, the appropriate
     * drawing context method is called.
     */
    public SwingViewMenuItem() {
        super("Swing View");
        setOnAction((EventHandler<ActionEvent>) new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                new SwingView();
            }
        });
    }

}
