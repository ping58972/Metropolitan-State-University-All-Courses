package gui.controller.buttons;

import controller.events.CreateLabelEvent;
import controller.states.DrawingContext;
import javafx.event.ActionEvent;

/**
 * The label button
 * 
 * @author Brahma Dathan
 *
 */
public class LabelButton extends GUIButton {
	/**
	 * Creates the label button with the proper text on the button
	 */
	public LabelButton() {
		super("Label");
	}

	@Override
	public void handle(ActionEvent event) {
		DrawingContext.instance().handleEvent(CreateLabelEvent.instance());
	}
}
