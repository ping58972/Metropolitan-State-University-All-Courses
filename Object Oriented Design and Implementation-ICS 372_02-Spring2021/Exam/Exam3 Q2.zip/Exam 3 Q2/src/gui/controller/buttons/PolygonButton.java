package gui.controller.buttons;

import controller.events.CreatePolygonEvent;
import controller.states.DrawingContext;
import javafx.event.ActionEvent;

/**
 * Button for drawing a polygon
 * 
 * @author Brahma Dathan
 *
 */
public class PolygonButton extends GUIButton {
	/**
	 * Creates the polygon button with the proper text on the button
	 */
	public PolygonButton() {
		super("Polygon");
	}

	@Override
	public void handle(ActionEvent event) {
		DrawingContext.instance().handleEvent(CreatePolygonEvent.instance());
	}
}
