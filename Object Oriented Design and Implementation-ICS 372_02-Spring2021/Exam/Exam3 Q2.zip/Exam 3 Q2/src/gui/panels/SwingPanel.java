/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package gui.panels;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.beans.PropertyChangeEvent;

import javax.swing.JPanel;

import gui.view.renderers.SwingRenderer;
import model.Model;
import view.PhysicalView;
import view.View;

/**
 * Display-only panel using the Swing technology
 * 
 * @author Brahma Dathan
 *
 */
public class SwingPanel extends JPanel implements PhysicalView {

	/**
	 * The panel where drawing occurs
	 *
	 */
	public SwingPanel(Model model) {
		View.instance().addPhysicalView(this);
		this.setPreferredSize(new Dimension(600, 400));
		repaint();
	}

	/**
	 * Paints the panel
	 * 
	 * @param graphics the Graphics object
	 */
	@Override
	public void paintComponent(Graphics graphics) {
		super.paintComponent(graphics);
		(SwingRenderer.instance()).setGraphics(graphics);
		graphics.setColor(Color.BLUE);
		View.instance().draw(SwingRenderer.instance());
	}

	@Override
	public void propertyChange(PropertyChangeEvent event) {
		repaint();
	}

	@Override
	public void setCursorToDefault() {
	}

	@Override
	public void setCursorToDrawing() {
	}

}
