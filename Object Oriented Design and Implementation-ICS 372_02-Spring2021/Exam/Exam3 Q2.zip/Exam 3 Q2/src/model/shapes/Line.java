package model.shapes;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import javafx.geometry.Point2D;
import view.Renderer;

/**
 * 
 * @author Brahma Dathan and Sarnath Ramnath
 * @Copyright (c) 2010
 
 * Redistribution and use with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - the use is for academic purpose only
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Neither the name of Brahma Dathan or Sarnath Ramnath
 *     may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * The authors do not make any claims regarding the correctness of the code in this module
 * and are not responsible for any loss or damage resulting from its use.  
 */

/**
 * Represents a line
 *
 */
public class Line extends Shape implements Serializable {
	private static final long serialVersionUID = 1L;
	private int numberOfElements;
	private transient Point2D point1;
	private transient Point2D point2;

	/**
	 * Creates a line with one endpoint; the second point is set to the first
	 * endpoint, so something can be rendered.
	 * 
	 * @param point1 the starting point
	 */

	public Line(Point2D point1) {
		this.point1 = this.point2 = point1;
	}

	/**
	 * Displays the line
	 */
	@Override
	public void render(Renderer renderer) {
		super.render(renderer);
		renderer.draw(point1.getX(), point1.getY(), point2.getX(), point2.getY());
	}

	/**
	 * Sets one of the endpoints
	 * 
	 * @param point an endpoint
	 */

	public void setPoint2(Point2D point) {
		point2 = point;
	}

	/**
	 * Returns one of the endpoints
	 * 
	 * @return an endpoint
	 */
	public Point2D getPoint1() {
		return point1;
	}

	/**
	 * Returns the second endpoint
	 * 
	 * @return an endpoint
	 */
	public Point2D getPoint2() {
		return point2;
	}

	/**
	 * Deserializes the line
	 * 
	 * @param serializedData the object input stream
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	private void readObject(ObjectInputStream serializedData) throws IOException, ClassNotFoundException {
		serializedData.defaultReadObject();
		double x1 = serializedData.readDouble();
		double y1 = serializedData.readDouble();
		point1 = new Point2D(x1, y1);
		double x2 = serializedData.readDouble();
		double y2 = serializedData.readDouble();
		point2 = new Point2D(x2, y2);
	}

	/**
	 * Serializes the line
	 * 
	 * @param serializedData object output stream
	 * @throws IOException
	 */
	private void writeObject(ObjectOutputStream serializedData) throws IOException {
		serializedData.defaultWriteObject();
		serializedData.writeDouble(point1.getX());
		serializedData.writeDouble(point1.getY());
		serializedData.writeDouble(point2.getX());
		serializedData.writeDouble(point2.getY());
	}

	@Override
	public String toString() {
		return "Line";
	}
}