/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package controller.states;

import controller.UndoManager;
import controller.events.AbandonEvent;
import controller.events.CreateLabelEvent;
import controller.events.CreateLineEvent;
import controller.events.CreatePolygonEvent;
import controller.events.PointInputEvent;
import controller.events.RedoRequestEvent;
import controller.events.UndoRequestEvent;
import view.View;

/**
 * Represents the state when no shape is being created.
 * 
 * @author Brahma Dathan
 *
 */
public class QuiescentState extends DrawingState {
	private static QuiescentState instance;

	/**
	 * Private constructor to make the class a singleton
	 */
	private QuiescentState() {

	}

	/**
	 * Returns the singleton object
	 *
	 * @return - the only instance of the class
	 */
	public static QuiescentState instance() {
		if (instance == null) {
			instance = new QuiescentState();
		}
		return instance;
	}

	@Override
	public void enter() {
		View.instance().setCursorToDefault();
	}

	@Override
	public void leave() {
		View.instance().setCursorToDrawing();
	}

	@Override
	public void handleEvent(CreateLabelEvent event) {
		DrawingContext.instance().changeCurrentState(LabelDrawingState.instance());
	}

	@Override
	public void handleEvent(CreateLineEvent event) {
		DrawingContext.instance().changeCurrentState(LineDrawingState.instance());
	}

	@Override
	public void handleEvent(CreatePolygonEvent event) {
		DrawingContext.instance().changeCurrentState(PolygonDrawingState.instance());
	}

	@Override
	public void handleEvent(PointInputEvent event) {
	}

	public void handleEvent(UndoRequestEvent event) {
		UndoManager.instance().undo();
	}

	public void handleEvent(RedoRequestEvent event) {
		UndoManager.instance().redo();
	}

	public void handleEvent(AbandonEvent event) {
	}
}
