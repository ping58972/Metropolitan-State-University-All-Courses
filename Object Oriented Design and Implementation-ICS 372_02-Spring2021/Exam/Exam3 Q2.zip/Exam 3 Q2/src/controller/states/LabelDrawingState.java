package controller.states;

import controller.UndoManager;
import controller.commands.Command;
import controller.commands.LabelCommand;
import controller.events.CharacterEvent;
import controller.events.ConfirmEvent;
import controller.events.DeleteCharacterEvent;
import controller.events.PointInputEvent;
import javafx.geometry.Point2D;
import view.View;

/**
 * Processes the command to draw a sequence of labels
 * 
 * @author Brahma Dathan
 *
 */
public class LabelDrawingState extends DrawingState {
	private static LabelDrawingState instance;

	/**
	 * Private constructor to make it a singleton
	 */
	private LabelDrawingState() {

	}

	/**
	 * Gets the instance of the singleton class
	 * 
	 * @return the only instance of this class
	 */
	public static LabelDrawingState instance() {
		if (instance == null) {
			instance = new LabelDrawingState();
		}
		return instance;
	}

	@Override
	public void handleEvent(PointInputEvent event) {
		Command command = DrawingContext.instance().getCommand();
		if (command != null) {
			((LabelCommand) command).removeCharacter();
			UndoManager.instance().endCommand();
			DrawingContext.instance().setCommand(null);
		}
		command = new LabelCommand(new Point2D(event.getX(), event.getY()));
		UndoManager.instance().beginCommand(command);
		DrawingContext.instance().setCommand(command);
		((LabelCommand) command).addCharacter("|");
	}

	@Override
	public void handleEvent(CharacterEvent event) {
		Command command = DrawingContext.instance().getCommand();
		if (command == null) {
			return;
		}
		((LabelCommand) command).removeCharacter();
		((LabelCommand) command).addCharacter(event.getCharacter() + "|");
		View.instance().update();
	}

	@Override
	public void handleEvent(DeleteCharacterEvent event) {
		Command command = DrawingContext.instance().getCommand();
		if (command == null) {
			return;
		}
		((LabelCommand) command).removeCharacter();
		((LabelCommand) command).removeCharacter();
		View.instance().update();
	}

	@Override
	public void handleEvent(ConfirmEvent event) {
		Command command = DrawingContext.instance().getCommand();
		if (command == null) {
			return;
		}
		((LabelCommand) command).removeCharacter();
		View.instance().update();
		UndoManager.instance().endCommand();
		DrawingContext.instance().setCommand(null);
		DrawingContext.instance().changeCurrentState(QuiescentState.instance());
	}

}
