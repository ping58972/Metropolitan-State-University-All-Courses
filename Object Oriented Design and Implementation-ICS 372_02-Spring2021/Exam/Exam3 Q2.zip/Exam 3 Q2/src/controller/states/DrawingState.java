/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package controller.states;

import controller.commands.Command;
import controller.events.AbandonEvent;
import controller.events.CharacterEvent;
import controller.events.ConfirmEvent;
import controller.events.ControlMouseClickEvent;
import controller.events.CreateLabelEvent;
import controller.events.CreateLineEvent;
import controller.events.CreatePolygonEvent;
import controller.events.DeleteCharacterEvent;
import controller.events.MouseEnterEvent;
import controller.events.MouseExitEvent;
import controller.events.OpenRequestEvent;
import controller.events.PointInputEvent;
import controller.events.RedoRequestEvent;
import controller.events.SaveRequestEvent;
import controller.events.ShiftEnterKeyEvent;
import controller.events.UndoRequestEvent;
import model.Model;

/**
 * The common drawing state
 *
 * @author Brahma Dathan
 *
 */
public abstract class DrawingState {

    /**
     * What to do when entering the state
     */
    public void enter() {
    }

    /**
     * What to do while leaving state
     */
    public void leave() {
    }

    /**
     * Handles the request to create a label.
     *
     * @param event - the event that represents label creation
     */
    public void handleEvent(CreateLabelEvent event) {
    }

    /**
     * Handles the request to create a line.
     *
     * @param event - the event that represents line creation
     */
    public void handleEvent(CreateLineEvent event) {
    }

    /**
     * Handles the request to create a polygon.
     *
     * @param event - the event that represents line creation
     */
    public void handleEvent(CreatePolygonEvent event) {
    }

    /**
     * Handles a specified point.
     *
     * @param event - the event that represents a new point
     */
    public void handleEvent(PointInputEvent event) {
    }

    /**
     * What to do when mouse is clicked with control down.
     * 
     * @param event represents the click of the mouse with control down
     */
    public void handleEvent(ControlMouseClickEvent event) {
    }

    /**
     * What to do when the Enter key is pressed with shift down.
     * 
     * @param event represents the Enter key is press with shift down
     */
    public void handleEvent(ShiftEnterKeyEvent event) {
    }

    /**
     * Abandons the current command
     *
     * @param event - the event that represents escape key press
     */
    public void handleEvent(AbandonEvent event) {
        Command command = DrawingContext.instance().getCommand();
        command.undo();
        DrawingContext.instance().setCommand(null);
        DrawingContext.instance().changeCurrentState(QuiescentState.instance());
    }

    /**
     * When the user confirms something, like the end of a sequence of labels or the
     * last vertex of a polygon, this method is called.
     *
     * @param event - the event that represents confirmation
     */
    public void handleEvent(ConfirmEvent event) {
    }

    /**
     * Handles the input of a character
     *
     * @param event - the event that represents a character input
     */
    public void handleEvent(CharacterEvent event) {
    }

    /**
     * Handles the deletion of a character
     *
     * @param event - the event that represents the deletion
     */
    public void handleEvent(DeleteCharacterEvent event) {
    }

    /**
     * Handles the entry of the mouse to the drawing panel
     * 
     * @param event
     */
    public void handleEvent(MouseEnterEvent event) {
    }

    /**
     * Handles the exit of the mouse from the drawing panel
     * 
     * @param event
     */
    public void handleEvent(MouseExitEvent event) {
    }

    /**
     * Handles the request to undo the last command not yet undone
     * 
     * @param event the event to distinguish this request
     */
    public void handleEvent(UndoRequestEvent event) {
    }

    /**
     * Handles the request to redo the last undone command
     * 
     * @param event the event to distinguish this request
     */
    public void handleEvent(RedoRequestEvent event) {
    }

    /**
     * Handles the request to open a file.
     *
     * @param event - the event that represents open request
     */
    public void handleEvent(OpenRequestEvent event) {
        Model.instance().retrieve(event.getFile());
    }

    /**
     * Handles the request to save a file.
     *
     * @param event - the event that represents save request
     */
    public void handleEvent(SaveRequestEvent event) {
        Model.instance().save(event.getFile());
    }
}
