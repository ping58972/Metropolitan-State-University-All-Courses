package controller.commands;

import javafx.geometry.Point2D;
import model.Model;
import model.shapes.Label;

/**
 * 
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
/**
 * Implements the Label command, so label creations can be undone. *
 * 
 * @author Brahma Dathan
 */
public class LabelCommand extends Command {
	private Label label;

	/**
	 * Creates the label
	 * 
	 * @param point starting point
	 */
	public LabelCommand(Point2D point) {
		label = new Label(point);
		execute();
	}

	/**
	 * Executes the command, essentially by supplying it to the model.
	 */
	@Override
	public void execute() {
		Model.instance().addShape(label);
	}

	/**
	 * Removes the label
	 */
	@Override
	public boolean undo() {
		Model.instance().removeShape(label);
		return true;
	}

	/**
	 * Re-creates the label by supplying it to the model
	 */
	@Override
	public boolean redo() {
		execute();
		return true;
	}

	/**
	 * Adds one more character to the label
	 * 
	 * @param character a new character in the label
	 */
	public void addCharacter(String character) {
		label.addCharacter(character);
	}

	/**
	 * removes the rightmost character in the label
	 */
	public void removeCharacter() {
		label.removeCharacter();
	}

}
