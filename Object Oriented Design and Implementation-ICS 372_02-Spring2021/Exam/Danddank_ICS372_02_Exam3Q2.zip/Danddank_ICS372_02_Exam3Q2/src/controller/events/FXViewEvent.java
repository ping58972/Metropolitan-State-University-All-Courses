package controller.events;

public class FXViewEvent extends DrawingEvent {
    private static FXViewEvent instance;

    /**
     * Private constructor for implementing the singleton pattern.
     */
    private FXViewEvent() {
    }

    /**
     * Static method to return the only instance of the class.
     * 
     * @return - the only instance
     */
    public static FXViewEvent instance() {
        if (instance == null) {
            instance = new FXViewEvent();
        }
        return instance;
    }
}
