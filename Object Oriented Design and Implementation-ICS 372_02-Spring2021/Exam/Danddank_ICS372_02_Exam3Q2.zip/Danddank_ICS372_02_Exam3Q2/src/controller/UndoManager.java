package controller;

/**
 * 
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan 
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
import java.util.Stack;

import controller.commands.Command;
import model.Model;

/**
 * The undo manager essentially supports undo and redo operations. In addition,
 * it has a command to begin and end commands.
 * 
 * @author Brahma Dathan
 *
 */
public class UndoManager {
	private Stack<Command> history;
	private Stack<Command> redoStack;
	private static UndoManager manager;

	/**
	 * Sets up the stacks.
	 */
	private UndoManager() {
		history = new Stack<Command>();
		redoStack = new Stack<Command>();
	}

	/**
	 * For the singleton pattern
	 * 
	 * @return the instance
	 */
	public static UndoManager instance() {
		if (manager == null) {
			manager = new UndoManager();
		}
		return manager;
	}

	/**
	 * Pushes a command onto the history stack. The redo stack is cleared.
	 * 
	 * @param command
	 */
	public void beginCommand(Command command) {
		redoStack.clear();
		history.push(command);
	}

	/**
	 * Normal end of a command. The command is ended and pushed onto the history
	 * stack.
	 */
	public void endCommand() {
		Model.instance().updateView();
	}

	/**
	 * Undoes the command by calling undo on the Command object. The command is
	 * moved to the redo stack (future).
	 */
	public void undo() {
		if (!(history.empty())) {
			Command command = (history.peek());
			if (command.undo()) {
				history.pop();
				redoStack.push(command);
			}
		}
	}

	/**
	 * Redoes the command by calling redo on the Command object that is on top of
	 * the redo stack (future). The command is then pushed onto the history stack.
	 */
	public void redo() {
		if (!(redoStack.empty())) {
			Command command = (redoStack.peek());
			if (command.redo()) {
				redoStack.pop();
				history.push(command);
			}
		}
	}
}