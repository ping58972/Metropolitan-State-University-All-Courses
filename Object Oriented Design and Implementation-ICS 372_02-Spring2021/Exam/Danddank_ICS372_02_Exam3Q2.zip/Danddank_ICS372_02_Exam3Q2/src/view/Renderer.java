package view;

/**
 * 
 * @author Brahma Dathan
 * @Copyright (c) 2018
 
 * Redistribution and use with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - the use is for academic purpose only
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Neither the name of Brahma Dathan or Sarnath Ramnath
 *     may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * The authors do not make any claims regarding the correctness of the code in this module
 * and are not responsible for any loss or damage resulting from its use.  
 */
/**
 * A given technology can implement this to draw the items in its own way.
 *
 */
public interface Renderer {
	/**
	 * Draw a line
	 * 
	 * @param line the line
	 */
	public abstract void draw(double x1, double y1, double x2, double y2);

	/**
	 * Draw a piece of text
	 * 
	 * @param x    the x coordinate of the text
	 * @param y    the y coordinate of the text
	 * @param text the text to be displayed
	 */
	public abstract void draw(double x, double y, String text);

	/**
	 * Draws an arc from a certain angle to another angle.
	 * 
	 * @param x          the x coordinate of the center
	 * @param y          the y coordinate of the center
	 * @param radius     the radius
	 * @param startAngle start angle
	 * @param endAngle   end angle
	 */
	public abstract void draw(double x, double y, double radius, double startAngle, double endAngle);

	/**
	 * This is a no-op draw. Should have no need to use this.
	 */
	public abstract void draw();

	/**
	 * Sets the color
	 * 
	 * @param red   the amount of red in a scale from 0 to 255
	 * @param green the amount of green in a scale from 0 to 255
	 * @param blue  the amount of blue in a scale from 0 to 255
	 */
	public abstract void setColor(int red, int green, int blue);

	/**
	 * Draws a single pixel at the spcified coordinate.
	 * 
	 * @param xCoordinate the x-coordinate of the pixel
	 * @param yCoordinate the y-coordinate of the pixel
	 */
	public abstract void draw(double x, double y);

	public abstract void drawL(double x1, double y1, double x2, double y2);
}
