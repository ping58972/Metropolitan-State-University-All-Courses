package gui.view.renderers;

/**
 * 
 * @author Brahma Dathan
 * @Copyright (c) 2018
 
 * Redistribution and use with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - the use is for academic purpose only
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Neither the name of Brahma Dathan or Sarnath Ramnath
 *     may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * The authors do not make any claims regarding the correctness of the code in this module
 * and are not responsible for any loss or damage resulting from its use.  
 */

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import javafx.scene.shape.ArcType;
import view.Renderer;

/**
 * A renderer that uses the JavaFX package
 *
 */
public class FXRenderer implements Renderer {
	private GraphicsContext graphics;
	private static FXRenderer renderer;

	/**
	 * For the singleton pattern
	 */
	private FXRenderer() {
	}

	/**
	 * Returns the instance
	 * 
	 * @return the instance
	 */
	public static FXRenderer instance() {
		if (renderer == null) {
			renderer = new FXRenderer();
		}
		return renderer;
	}

	/**
	 * The Graphics object for drawing
	 * 
	 * @param graphics the Graphics object
	 */
	public void setGraphics(GraphicsContext graphics) {
		this.graphics = graphics;
	}

	@Override
	public void draw(double x1, double y1, double x2, double y2) {
		graphics.strokeLine(x1, y1, x2, y2);
	}

	@Override
	public void draw(double x1, double y1, String text) {
		graphics.strokeText(text, x1, y1);
	}

	@Override
	public void draw(double x1, double y1, double radius, double startAngle, double endAngle) {
		graphics.strokeArc(x1 - radius, y1 - radius, 2 * radius, 2 * radius, startAngle, endAngle - startAngle,
				ArcType.OPEN);
	}

	@Override
	public void draw() {
	}

	@Override
	public void setColor(int red, int green, int blue) {
		graphics.setStroke(new Color(red / 255, green / 255, blue / 255, 1));
	}

	@Override
	public void draw(double x, double y) {
		draw(x, y, x, y);

	}

	@Override
	public void drawL(double x1, double y1, double x2, double y2) {
		graphics.strokeLine(x1, y1, x1, y2);
		graphics.strokeLine(x1, y2, x2, y2);
	}
}