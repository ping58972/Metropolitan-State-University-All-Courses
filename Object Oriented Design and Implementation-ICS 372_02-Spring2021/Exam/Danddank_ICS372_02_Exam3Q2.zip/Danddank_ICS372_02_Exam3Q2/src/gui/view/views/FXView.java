package gui.view.views;

import gui.panels.FXPanel;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import view.View;

/**
 * The view for JavaFX. This is a display-only view.
 * 
 * @author Brahma Dathan
 *
 */
public class FXView extends Stage implements EventHandler<WindowEvent> {
    private FXPanel drawingPanel;

    /**
     * Simply sets up the FXPanel in a Stage.
     */
    public FXView() {
        drawingPanel = new FXPanel();
        Scene scene = new Scene(drawingPanel);
        setScene(scene);
        setTitle("FX View ");
        this.setOnCloseRequest(this);
        show();

    }

    @Override
    public void handle(WindowEvent event) {
        View.instance().removePhysicalView(drawingPanel);
    }
}
