package gui.controller.buttons;

import controller.events.CreateLEvent;
import controller.states.DrawingContext;
import javafx.event.ActionEvent;

/**
 * The line button
 * 
 * @author Brahma Dathan
 *
 */
public class LButton extends GUIButton {
	/**
	 * Creates the line button with the proper text on the button
	 */
	public LButton() {
		super("L");
	}

	@Override
	public void handle(ActionEvent event) {
		DrawingContext.instance().handleEvent(CreateLEvent.instance());
	}
}
