/**
 * 
 * @author Brahma Dathan
 * 
 *         Redistribution and use with or without modification, are permitted
 *         provided that the following conditions are met: the use is for
 *         academic purpose only - Redistributions of source code must retain
 *         the above copyright notice, this list of conditions and the following
 *         disclaimer. - The name of Brahma Dathan may not be used to
 *         endorse or promote products derived from this software without
 *         specific prior written permission.
 *
 *         The author does not make any claims regarding the correctness of the
 *         code in this module and are not responsible for any loss or damage
 *         resulting from its use.
 */
/**
 * The menu item for FX
 * 
 * @author Brahma Dathan
 *
 */
package gui.panels;

import controller.events.MouseEnterEvent;
import controller.events.MouseExitEvent;
import controller.states.DrawingContext;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Cursor;
import view.PhysicalView;

/**
 * Sets up the area where the mouse clicks and keyboard events occur.
 *
 * @author Brahma Dathan
 *
 */
public class DrawingPanel extends FXPanel implements PhysicalView {

	private Cursor drawingPanelCursor;

	/**
	 * Sets up the listeners
	 *
	 * @param model
	 */
	public DrawingPanel() {
		setOnMouseEntered(new EventHandler() {
			@Override
			public void handle(Event event) {
				DrawingContext.instance().handleEvent(MouseEnterEvent.instance());
				setCursor(drawingPanelCursor);
			}

		});
		setOnMouseExited(new EventHandler() {
			@Override
			public void handle(Event event) {
				DrawingContext.instance().handleEvent(MouseExitEvent.instance());
				setCursor(Cursor.DEFAULT);
			}

		});
	}

	@Override
	public void setCursorToDefault() {
		drawingPanelCursor = Cursor.DEFAULT;
		setCursor(Cursor.DEFAULT);
	}

	@Override
	public void setCursorToDrawing() {
		drawingPanelCursor = Cursor.CROSSHAIR;
	}
}
