package model.shapes;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

import javafx.geometry.Point2D;
import view.Renderer;

/**
 * 
 * @author Brahma Dathan and Sarnath Ramnath
 * @Copyright (c) 2010
 
 * Redistribution and use with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - the use is for academic purpose only
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Neither the name of Brahma Dathan or Sarnath Ramnath
 *     may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * The authors do not make any claims regarding the correctness of the code in this module
 * and are not responsible for any loss or damage resulting from its use.  
 */

/**
 * Implements a label; stores the end points and text.
 *
 */
public class Label extends Shape implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private transient Point2D startingPoint;
	private String text = "";

	/**
	 * Creates a label at the specified starting vertex
	 * 
	 * @param point the starting point of the label
	 */
	public Label(Point2D point) {
		startingPoint = point;
	}

	/**
	 * Adds one more character to the label
	 * 
	 * @param character a new character in the label
	 */
	public void addCharacter(String character) {
		text += character;
	}

	/**
	 * removes the rightmost character in the label
	 */
	public void removeCharacter() {
		if (text.length() > 0) {
			text = text.substring(0, text.length() - 1);
		}
	}

	/**
	 * Displays the label
	 */
	@Override
	public void render(Renderer renderer) {
		super.render(renderer);
		if (startingPoint != null) {
			renderer.draw((int) startingPoint.getX(), (int) startingPoint.getY(), text);
		}
	}

	/**
	 * Returns the actual text in the label
	 * 
	 * @return the text in the label
	 */
	public String getText() {
		return text;
	}

	/**
	 * Returns the starting point
	 * 
	 * @return starting point
	 */
	public Point2D getStartingPoint() {
		return startingPoint;
	}

	/**
	 * Deserializes the label
	 * 
	 * @param serializedData the object input stream
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	private void readObject(ObjectInputStream serializedData) throws IOException, ClassNotFoundException {
		serializedData.defaultReadObject();
		double x = serializedData.readDouble();
		double y = serializedData.readDouble();
		startingPoint = new Point2D(x, y);
	}

	/**
	 * Serializes the label
	 * 
	 * @param serializedData object output stream
	 * @throws IOException
	 */
	private void writeObject(ObjectOutputStream serializedData) throws IOException {
		serializedData.defaultWriteObject();
		serializedData.writeDouble(startingPoint.getX());
		serializedData.writeDouble(startingPoint.getY());
	}

	@Override
	public String toString() {
		return "Label [startingPoint=" + startingPoint + ", text=" + text + "]";
	}

}