/**
 * 
 * @author Brahma Dathan
 * @Copyright (c) 2018
 
 * Redistribution and use with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - the use is for academic purpose only
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Neither the name of Brahma Dathan or Sarnath Ramnath
 *     may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * The authors do not make any claims regarding the correctness of the code in this module
 * and are not responsible for any loss or damage resulting from its use.  
 */
package model.shapes;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Arrays;

import javafx.geometry.Point2D;
import view.Renderer;

public class Polygon extends Shape implements Serializable {
	private static final long serialVersionUID = 1L;
	private transient Point2D[] points;
	private transient int numberOfPoints;

	public Polygon() {
		points = new Point2D[10];
	}

	/**
	 * Adds one more vertex to the polygon
	 * 
	 * @param point
	 */
	public void addPoint(Point2D point) {
		if (this.points.length == numberOfPoints + 1) {
			Point2D[] temp = new Point2D[numberOfPoints * 2];
			System.arraycopy(points, 0, temp, 0, numberOfPoints);
			points = temp;
		}
		points[numberOfPoints++] = point;
		points[numberOfPoints] = point;
	}

	/**
	 * Adds the first vertex as the last vertex, so the drawing would be complete.
	 */
	public void end() {
		points[numberOfPoints] = points[0];
	}

	@Override
	public void render(Renderer renderer) {
		super.render(renderer);
		for (int index = 0; index < numberOfPoints; index++) {
			renderer.draw(points[index].getX(), points[index].getY(), points[index + 1].getX(),
					points[index + 1].getY());
		}
	}

	/**
	 * Deserializes the polygon
	 * 
	 * @param serializedData the object input stream
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	private void readObject(ObjectInputStream serializedData) throws IOException, ClassNotFoundException {
		serializedData.defaultReadObject();
		double[] x = (double[]) serializedData.readObject();
		double[] y = (double[]) serializedData.readObject();
		numberOfPoints = (int) serializedData.readInt();
		points = new Point2D[numberOfPoints + 1];
		for (int index = 0; index < numberOfPoints; index++) {
			points[index] = new Point2D(x[index], y[index]);
		}
		points[numberOfPoints] = points[0];
	}

	/**
	 * Serializes the polygon
	 * 
	 * @param serializedData object output stream
	 * @throws IOException
	 */
	private void writeObject(ObjectOutputStream serializedData) throws IOException {
		serializedData.defaultWriteObject();
		double[] x = new double[numberOfPoints];
		double[] y = new double[numberOfPoints];
		for (int index = 0; index < numberOfPoints; index++) {
			x[index] = points[index].getX();
			y[index] = points[index].getY();
		}
		serializedData.writeObject(x);
		serializedData.writeObject(y);
		serializedData.writeInt(numberOfPoints);
	}

	@Override
	public String toString() {
		return "Polygon [points=" + Arrays.toString(points) + ", numberOfPoints=" + numberOfPoints + "]";
	}
}
