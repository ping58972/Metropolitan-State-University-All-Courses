/**
 * 
 */
package Danddank_ICS372_02_Exam1Q2;

/**
 * @author Nalongsone Danddank
 *
 */
public class DanddankDriver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			Band band1 = new Band(50, 100, 10, 30); // x = 50, y = 100, width = 10, outer radius = 30
			System.out.println(band1.getArea()); // Returns the area occupied by the band
			band1.display(); // displays the Band object as shown in the output
			Band band2 = new Band(20, 30, 40, 10); // outer radius is too small for the width
		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
