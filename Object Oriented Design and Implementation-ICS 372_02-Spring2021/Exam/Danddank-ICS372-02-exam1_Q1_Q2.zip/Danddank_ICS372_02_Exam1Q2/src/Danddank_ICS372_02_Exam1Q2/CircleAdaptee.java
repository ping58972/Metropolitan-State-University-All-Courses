/**
 * 
 */
package Danddank_ICS372_02_Exam1Q2;

/**
 * @author Nalongsone Danddank
 *
 */
public interface CircleAdaptee {

	public double getArea();

	public void display();
}
