/**
 * 
 */
package Danddank_ICS372_02_Exam1Q2;

/**
 * @author Nalongsone Danddank
 *
 */
public class Band implements CircleAdaptee {

	private Circle outerCircle;
	private Circle innerCircle;
	private double width;

	/**
	 * @param width
	 */
	public Band(double x, double y, double width, double radius) throws Exception {
		if (radius <= width) {
			throw new Exception("Illegal parameters.");
		}
		this.outerCircle = new Circle(x, y, radius);
		this.innerCircle = new Circle(x, y, radius - width);
		this.width = width;
	}

	@Override
	public double getArea() {

		return outerCircle.getArea() - innerCircle.getArea();
	}

	@Override
	public void display() {

		String string = innerCircle.toString() + " width " + this.width;
		System.out.println(string);
	}

	public double getWidth() {
		return width;
	}

	public void setWidth(double width) {
		this.width = width;
	}

}
