/**
 * 
 */
package Danddank_ICS372_02_Exam1Q1;

/**
 * @author Nalongsone Danddank
 *
 */
public class DanddankDriver {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Ticket ticket1 = new Advance(0);
		System.out.println(ticket1);
		Ticket ticket2 = new Advance(5);
		System.out.println(ticket2);
		Ticket ticket3 = new Advance(15);
		System.out.println(ticket3);
		StudentAdvance studentTicket = new StudentAdvance(20);
		studentTicket.setStudentId("12345");
		System.out.println(studentTicket);
	}

}
