/**
 * 
 */
package Danddank_ICS372_02_Exam1Q1;

/**
 * @author Nalongsone Danddank
 *
 */
public class StudentAdvance extends Advance {

	private String studentId = "xxxx";

	/**
	 * @param numberDays
	 */
	public StudentAdvance(int numberDays) {
		super(numberDays);

	}

	@Override
	public double getPrice() {
		// TODO Auto-generated method stub
		return super.getPrice() / 2;
	}

	@Override
	public String toString() {
		return super.toString() + "\nStudent ID: " + studentId;
	}

	public String getStudentId() {
		return studentId;
	}

	public void setStudentId(String studentId) {
		this.studentId = studentId;
	}

}
