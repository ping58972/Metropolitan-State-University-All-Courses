/**
 * 
 */
package Danddank_ICS372_02_Exam1Q1;

/**
 * @author Nalongsone Danddank
 *
 */
public abstract class Ticket {
	private static int serialNumber = 10;

	public Ticket() {
		serialNumber++;
	}

	public static int getSerialNumber() {
		return serialNumber;
	}

	public abstract double getPrice();

	@Override
	public String toString() {
		return "Ticket " + this.getSerialNumber() + " price " + getPrice();
	}

}
