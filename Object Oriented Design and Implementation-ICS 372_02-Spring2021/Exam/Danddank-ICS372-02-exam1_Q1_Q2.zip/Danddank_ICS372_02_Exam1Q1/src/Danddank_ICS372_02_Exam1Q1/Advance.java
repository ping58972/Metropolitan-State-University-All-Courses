/**
 * 
 */
package Danddank_ICS372_02_Exam1Q1;

/**
 * @author Nalongsone Danddank
 *
 */
public class Advance extends Ticket {

	private double price;

	public void setPrice(int numberDays) {
		if (numberDays >= 10) {
			this.price = 35;
		} else if (numberDays < 10 && numberDays >= 1) {
			this.price = 45;
		} else {
			this.price = 50;
		}

	}

	public Advance(int numberDays) {
		setPrice(numberDays);
	}

	@Override
	public double getPrice() {
		// TODO Auto-generated method stub
		return this.price;
	}

}
