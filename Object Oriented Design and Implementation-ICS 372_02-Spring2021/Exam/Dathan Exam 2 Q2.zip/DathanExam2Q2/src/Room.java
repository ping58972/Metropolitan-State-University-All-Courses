/**
 * Implements the functionality for a room in a hotel. The field
 * totalRentPerNight stores the total rent for a single night in this room for
 * the specified number of guests.
 * 
 * @author mh6624pa
 *
 */
public class Room {
    private int roomNumber;
    private int type;
    private double basicChargePerNight;
    private double extraChargePerPersonPerNight;
    private double totalRentPerNight;
    public static final int SINGLE_ROOM = 1;
    public static final int DOUBLE_ROOM = 2;
    public static final int SUITE = 3;

    /**
     * Store the room number, type, the basic charge, and the extra charge per
     * person per night.
     * 
     * @param roomNumber                   the room number
     * @param type                         single, double, or suite
     * @param basicChargePerNight          charge per night if there are no extra
     *                                     occupants
     * @param extraChargePerPersonPerNight charge for each additional person per
     *                                     night
     */
    public Room(int roomNumber, int type, double basicChargePerNight, double extraChargePerPersonPerNight) {
        this.roomNumber = roomNumber;
        this.type = type;
        this.basicChargePerNight = basicChargePerNight;
        this.extraChargePerPersonPerNight = extraChargePerPersonPerNight;
    }

    /**
     * Computes the total charge per night of occupancy for this room for the given
     * number of guests.
     * 
     * @param numberOfGuests number of guests
     * @throws Exception thrown if number of guests exceeds a certain number, which
     *                   is dependent on the room type
     */
    public void computeTotalChargePerNight(int numberOfGuests) throws Exception {
        if (type == SINGLE_ROOM) {
            if (numberOfGuests < 1 || numberOfGuests > 2) {
                throw new Exception("Invalid number of guests");
            }
            totalRentPerNight = basicChargePerNight + (numberOfGuests - 1) * extraChargePerPersonPerNight;
        } else if (type == DOUBLE_ROOM) {
            if (numberOfGuests < 1 || numberOfGuests > 4) {
                throw new Exception("Invalid number of guests");
            }

            totalRentPerNight = basicChargePerNight + Math.max(0, (numberOfGuests - 2)) * extraChargePerPersonPerNight;
        } else if (type == SUITE) {
            if (numberOfGuests < 1 || numberOfGuests > 8) {
                throw new Exception("Invalid number of guests");
            }
            totalRentPerNight = basicChargePerNight + Math.max(0, (numberOfGuests - 4)) * extraChargePerPersonPerNight;
        }
    }

    public int getRoomNumber() {
        return roomNumber;
    }

    public int getType() {
        return type;
    }

    public double getBasicChargePerNight() {
        return basicChargePerNight;
    }

    public double getExtraChargePerPersonPerNight() {
        return extraChargePerPersonPerNight;
    }

    public double getTotalRentPerNight() {
        return totalRentPerNight;
    }

    /**
     * A very elementary test of the functionality
     * 
     * @param args not used
     */
    public static void main(String[] args) {
        Room singleRoom = new Room(1, Room.SINGLE_ROOM, 50.0, 10.0);
        Room doubleRoom = new Room(2, Room.DOUBLE_ROOM, 90.0, 20.0);
        Room suite = new Room(3, Room.SUITE, 200.0, 50.0);
        try {
            singleRoom.computeTotalChargePerNight(2);
            assert singleRoom.getTotalRentPerNight() == 60.0;

        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            singleRoom.computeTotalChargePerNight(1);
            assert singleRoom.getTotalRentPerNight() == 50.0;
        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            singleRoom.computeTotalChargePerNight(3);
        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            doubleRoom.computeTotalChargePerNight(4);
            assert doubleRoom.getTotalRentPerNight() == 130.0;
        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            doubleRoom.computeTotalChargePerNight(2);
            assert doubleRoom.getTotalRentPerNight() == 90.0;
        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            doubleRoom.computeTotalChargePerNight(5);
        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            suite.computeTotalChargePerNight(4);
            assert suite.getTotalRentPerNight() == 200.0;
        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            suite.computeTotalChargePerNight(8);
            assert suite.getTotalRentPerNight() == 400.0;
        } catch (Exception e) {
            System.out.println(e);
        }
        try {
            suite.computeTotalChargePerNight(9);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
