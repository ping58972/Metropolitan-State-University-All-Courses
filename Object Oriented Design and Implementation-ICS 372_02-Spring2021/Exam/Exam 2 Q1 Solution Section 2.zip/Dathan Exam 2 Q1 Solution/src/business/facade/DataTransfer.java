package business.facade;

import business.entities.Book;
import business.entities.Member;

/**
 * The DataTransfer class is used to facilitate data transfer between Library
 * and UserInterface. It is also used to support iterating over Member and Book
 * objects. The class stores copies of fields that may be sent in either
 * direction.
 * 
 * @author Brahma Dathan
 *
 */
public abstract class DataTransfer {
    private String bookId;
    private String bookTitle;
    private String bookAuthor;
    private String bookBorrower;
    private String bookDueDate;
    private String memberId;
    private String memberName;
    private String memberAddress;
    private String memberPhone;

    /**
     * This sets all fields to "none".
     */
    public DataTransfer() {
        reset();
    }

    public String getBookId() {
        return bookId;
    }

    public void setBookId(String bookId) {
        this.bookId = bookId;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public String getBookBorrower() {
        return bookBorrower;
    }

    public void setBookBorrower(String bookBorrower) {
        this.bookBorrower = bookBorrower;
    }

    public String getBookDueDate() {
        return bookDueDate;
    }

    public void setBookDueDate(String bookDueDate) {
        this.bookDueDate = bookDueDate;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }

    public String getMemberName() {
        return memberName;
    }

    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    public String getMemberPhone() {
        return memberPhone;
    }

    public void setMemberPhone(String memberPhone) {
        this.memberPhone = memberPhone;
    }

    /**
     * Sets all the member-related fields using the Member parameter.
     * 
     * @param member the member whose fields should be copied.
     */
    public void setMemberFields(Member member) {
        memberId = member.getId();
        memberName = member.getName();
        memberPhone = member.getPhone();
        memberAddress = member.getAddress();
    }

    public String getBookAuthor() {
        return bookAuthor;
    }

    public void setBookAuthor(String bookAuthor) {
        this.bookAuthor = bookAuthor;
    }

    public String getMemberAddress() {
        return memberAddress;
    }

    public void setMemberAddress(String memberAddress) {
        this.memberAddress = memberAddress;
    }

    /**
     * Sets all the book-related fields using the Book parameter. If the book is not
     * issued "none" is stored in the borrower and due date fields.
     * 
     * @param book the book whose fields should be copied.
     */
    public void setBookFields(Book book) {
        if (book.getBorrower() != null) {
            bookBorrower = book.getBorrower().getId();
            bookDueDate = book.getDueDate();
        } else {
            bookBorrower = "No borrower";
            bookDueDate = "Not Applicable";
        }
        bookId = book.getId();
        bookTitle = book.getTitle();
        bookAuthor = book.getAuthor();
    }

    /**
     * Sets all String fields to "none"
     */
    public void reset() {
        bookId = "none";
        bookTitle = "none";
        bookBorrower = "No borrower";
        bookAuthor = "none";
        memberId = "none";
        memberName = "none";
        memberPhone = "none";
        memberAddress = "none";
    }
}
