package ui;

/**
 * 
 * @author Brahma Dathan and Sarnath Ramnath
 * @Copyright (c) 2010
 
 * Redistribution and use with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - the use is for academic purpose only
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Neither the name of Brahma Dathan or Sarnath Ramnath
 *     may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * The authors do not make any claims regarding the correctness of the code in this module
 * and are not responsible for any loss or damage resulting from its use.  
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Iterator;
import java.util.StringTokenizer;

import business.entities.Transaction;
import business.facade.Library;
import business.facade.Request;
import business.facade.Result;

/**
 * 
 * This class implements the user interface for the Library project. The
 * commands are encoded as integers using a number of static final variables. A
 * number of utility methods exist to make it easier to parse the input.
 *
 */
public class UserInterface {
    private static UserInterface userInterface;
    private BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
    private static Library library;
    private static final int EXIT = 0;
    private static final int ADD_MEMBER = 1;
    private static final int ADD_BOOKS = 2;
    private static final int ISSUE_BOOKS = 3;
    private static final int RETURN_BOOKS = 4;
    private static final int RENEW_BOOKS = 5;
    private static final int REMOVE_BOOKS = 6;
    private static final int PLACE_HOLD = 7;
    private static final int REMOVE_HOLD = 8;
    private static final int PROCESS_HOLD = 9;
    private static final int GET_TRANSACTIONS = 10;
    private static final int GET_MEMBERS = 11;
    private static final int GET_BOOKS = 12;
    private static final int GET_MEMBER_NAME = 13;
    private static final int SAVE = 14;
    private static final int HELP = 15;

    /**
     * Made private for singleton pattern. Conditionally looks for any saved data.
     * Otherwise, it gets a singleton Library object.
     */
    private UserInterface() {
        if (yesOrNo("Look for saved data and  use it?")) {
            retrieve();
        } else {
            library = Library.instance();
        }

    }

    /**
     * Supports the singleton pattern
     * 
     * @return the singleton object
     */
    public static UserInterface instance() {
        if (userInterface == null) {
            return userInterface = new UserInterface();
        } else {
            return userInterface;
        }
    }

    /**
     * Gets a token after prompting
     * 
     * @param prompt - whatever the user wants as prompt
     * @return - the token from the keyboard
     * 
     */
    public String getToken(String prompt) {
        do {
            try {
                System.out.println(prompt);
                String line = reader.readLine();
                StringTokenizer tokenizer = new StringTokenizer(line, "\n\r\f");
                if (tokenizer.hasMoreTokens()) {
                    return tokenizer.nextToken();
                }
            } catch (IOException ioe) {
                System.exit(0);
            }
        } while (true);
    }

    /**
     * Gets a name after prompting
     * 
     * @param prompt - whatever the user wants as prompt
     * @return - the token from the keyboard
     * 
     */
    public String getName(String prompt) {
        do {
            try {
                System.out.println(prompt);
                String line = reader.readLine();
                return line;
            } catch (IOException ioe) {
                System.exit(0);
            }
        } while (true);

    }

    /**
     * Queries for a yes or no and returns true for yes and false for no
     * 
     * @param prompt The string to be prepended to the yes/no prompt
     * @return true for yes and false for no
     * 
     */
    private boolean yesOrNo(String prompt) {
        String more = getToken(prompt + " (Y|y)[es] or anything else for no");
        if (more.charAt(0) != 'y' && more.charAt(0) != 'Y') {
            return false;
        }
        return true;
    }

    /**
     * Converts the string to a number
     * 
     * @param prompt the string for prompting
     * @return the integer corresponding to the string
     * 
     */
    public int getNumber(String prompt) {
        do {
            try {
                String item = getToken(prompt);
                Integer number = Integer.valueOf(item);
                return number.intValue();
            } catch (NumberFormatException nfe) {
                System.out.println("Please input a number ");
            }
        } while (true);
    }

    /**
     * Prompts for a date and gets a date object
     * 
     * @param prompt the prompt
     * @return the data as a Calendar object
     */
    public Calendar getDate(String prompt) {
        do {
            try {
                Calendar date = new GregorianCalendar();
                String item = getToken(prompt);
                DateFormat dateFormat = SimpleDateFormat.getDateInstance(DateFormat.SHORT);
                date.setTime(dateFormat.parse(item));
                return date;
            } catch (Exception fe) {
                System.out.println("Please input a date as mm/dd/yy");
            }
        } while (true);
    }

    /**
     * Prompts for a command from the keyboard
     * 
     * @return a valid command
     * 
     */
    public int getCommand() {
        do {
            try {
                int value = Integer.parseInt(getToken("Enter command:" + HELP + " for help"));
                if (value >= EXIT && value <= HELP) {
                    return value;
                }
            } catch (NumberFormatException nfe) {
                System.out.println("Enter a number");
            }
        } while (true);
    }

    /**
     * Displays the help screen
     * 
     */
    public void help() {
        System.out.println("Enter a number between 0 and 12 as explained below:");
        System.out.println(EXIT + " to Exit\n");
        System.out.println(ADD_MEMBER + " to add a member");
        System.out.println(ADD_BOOKS + " to  add books");
        System.out.println(ISSUE_BOOKS + " to  issue books to a  member");
        System.out.println(RETURN_BOOKS + " to  return books ");
        System.out.println(RENEW_BOOKS + " to  renew books ");
        System.out.println(REMOVE_BOOKS + " to  remove books");
        System.out.println(PLACE_HOLD + " to  place a hold on a book");
        System.out.println(REMOVE_HOLD + " to  remove a hold on a book");
        System.out.println(PROCESS_HOLD + " to  process holds");
        System.out.println(GET_TRANSACTIONS + " to  print transactions");
        System.out.println(GET_MEMBERS + " to  print all members");
        System.out.println(GET_BOOKS + " to  print all books");
        System.out.println(GET_MEMBER_NAME + " to get member name");
        System.out.println(SAVE + " to  save data");
        System.out.println(HELP + " for help");
    }

    /**
     * Method to be called for adding a member. Prompts the user for the appropriate
     * values and uses the appropriate Library method for adding the member.
     * 
     */
    public void addMember() {
        Request.instance().setMemberName(getName("Enter member name"));
        Request.instance().setMemberAddress(getName("Enter address"));
        Request.instance().setMemberPhone(getName("Enter phone"));
        Result result = library.addMember(Request.instance());
        if (result.getResultCode() != Result.OPERATION_COMPLETED) {
            System.out.println("Could not add member");
        } else {
            System.out.println(result.getMemberName() + "'s id is " + result.getMemberId());
        }
    }

    /**
     * Method to be called for adding a book. Prompts the user for the appropriate
     * values and uses the appropriate Library method for adding the book.
     * 
     */
    public void addBooks() {
        do {
            Request.instance().setBookTitle(getName("Enter  title"));
            Request.instance().setBookId(getToken("Enter id"));
            Request.instance().setBookAuthor(getName("Enter author"));
            Result result = library.addBook(Request.instance());
            if (result.getResultCode() != Result.OPERATION_COMPLETED) {
                System.out.println("Book could not be added");
            } else {
                System.out.println("Book " + result.getBookTitle() + " added");
            }
        } while (yesOrNo("Add more books?"));
    }

    /**
     * Method to be called for issuing books. Prompts the user for the appropriate
     * values and uses the appropriate Library method for issuing books.
     * 
     */
    public void issueBooks() {
        Request.instance().setMemberId(getToken("Enter member id"));
        Result result = library.searchMembership(Request.instance());
        if (result.getResultCode() != Result.OPERATION_COMPLETED) {
            System.out.println("No member with id " + Request.instance().getMemberId());
            return;
        }
        do {
            Request.instance().setBookId(getToken("Enter book id"));
            result = library.issueBook(Request.instance());
            if (result.getResultCode() == Result.OPERATION_COMPLETED) {
                System.out.println("Book " + result.getBookTitle() + " issued to " + result.getMemberName()
                        + " is due on " + result.getBookDueDate());
            } else {
                System.out.println("Book could not be issued");
            }
        } while (yesOrNo("Issue more books?"));
    }

    /**
     * Method to be called for renewing books. Prompts the user for the appropriate
     * values and uses the appropriate Library method for renewing books.
     * 
     */
    public void renewBooks() {
        Request.instance().setMemberId(getToken("Enter member id"));
        Result result = library.searchMembership(Request.instance());
        if (result.getResultCode() != Result.OPERATION_COMPLETED) {
            System.out.println("No member with id " + Request.instance().getMemberId());
            return;
        }
        Iterator<Result> issuedBooks = library.getBooks(Request.instance());
        while (issuedBooks.hasNext()) {
            result = issuedBooks.next();
            if (yesOrNo(result.getBookTitle())) {
                Request.instance().setBookId(result.getBookId());
                result = library.renewBook(Request.instance());
                if (result.getResultCode() == Result.OPERATION_COMPLETED) {
                    System.out.println("Book " + result.getBookTitle() + " renewed for " + result.getMemberName()
                            + " is due on " + result.getBookDueDate());
                } else {
                    System.out.println("Book is not renewable");
                }
            }
        }
    }

    /**
     * Method to be called for returning books. Prompts the user for the appropriate
     * values and uses the appropriate Library method for returning books.
     * 
     */
    public void returnBooks() {
        do {
            Request.instance().setBookId(getToken("Enter book id"));
            Result result = library.returnBook(Request.instance());
            switch (result.getResultCode()) {
            case Result.BOOK_NOT_FOUND:
                System.out.println("No such Book with id " + Request.instance().getBookId() + " in Library");
                break;
            case Result.BOOK_NOT_ISSUED:
                System.out.println(" Book " + result.getBookTitle() + " was not checked out");
                break;
            case Result.BOOK_HAS_HOLD:
                System.out.println("Book " + result.getBookTitle() + "has a hold");
                break;
            case Result.OPERATION_FAILED:
                System.out.println("Book " + result.getBookTitle() + " could not be returned");
                break;
            case Result.OPERATION_COMPLETED:
                System.out.println(" Book " + result.getBookTitle() + " has been returned");
                break;
            default:
                System.out.println("An error has occurred");
            }
            if (!yesOrNo("Return more books?")) {
                break;
            }
        } while (true);
    }

    /**
     * Method to be called for removing books. Prompts the user for the appropriate
     * values and uses the appropriate Library method for removing books.
     * 
     */
    public void removeBooks() {
        do {
            Request.instance().setBookId(getToken("Enter book id"));
            Result result = library.removeBook(Request.instance());
            switch (result.getResultCode()) {
            case Result.BOOK_NOT_FOUND:
                System.out.println("No such Book with id " + Request.instance().getBookId() + " in Library");
                break;
            case Result.BOOK_ISSUED:
                System.out.println(" Book with id " + Request.instance().getBookId() + " is currently checked out");
                break;
            case Result.BOOK_HAS_HOLD:
                System.out.println("Book with id " + Request.instance().getBookId() + " has a hold");
                break;
            case Result.OPERATION_FAILED:
                System.out.println("Book could not be removed");
                break;
            case Result.OPERATION_COMPLETED:
                System.out.println(" Book has been removed");
                break;
            default:
                System.out.println("An error has occurred");
            }
            if (!yesOrNo("Remove more books?")) {
                break;
            }
        } while (true);
    }

    /**
     * Method to be called for placing a hold. Prompts the user for the appropriate
     * values and uses the appropriate Library method for placing a hold.
     * 
     */
    public void placeHold() {
        Request.instance().setMemberId(getToken("Enter member id"));
        Request.instance().setBookId(getToken("Enter book id"));
        Request.instance().setHoldDuration(getNumber("Enter duration of hold"));
        Result result = library.placeHold(Request.instance());
        switch (result.getResultCode()) {
        case Result.BOOK_NOT_FOUND:
            System.out.println("No such Book with id " + Request.instance().getBookId() + " in Library");
            break;
        case Result.BOOK_NOT_ISSUED:
            System.out.println(" Book with id " + Request.instance().getBookId() + " is not checked out");
            break;
        case Result.NO_SUCH_MEMBER:
            System.out.println(Request.instance().getMemberId() + " is not a valid member ID");
            break;
        case Result.OPERATION_COMPLETED:
            System.out.println("A hold has been placed for member " + result.getMemberName() + " for book "
                    + result.getBookTitle());
            break;
        default:
            System.out.println("An error has occurred");
        }
    }

    /**
     * Method to be called for removing a holds. Prompts the user for the
     * appropriate values and uses the appropriate Library method for removing a
     * hold.
     * 
     */
    public void removeHold() {
        Request.instance().setMemberId(getToken("Enter member id"));
        Request.instance().setBookId(getToken("Enter book id"));
        Result result = library.removeHold(Request.instance());
        switch (result.getResultCode()) {
        case Result.BOOK_NOT_FOUND:
            System.out.println("No such Book with id " + Request.instance().getBookId() + " in Library");
            break;
        case Result.NO_SUCH_MEMBER:
            System.out.println("No such Member with id " + Request.instance().getMemberId() + " in Library");
            break;
        case Result.BOOK_NOT_ISSUED:
            System.out.println("Book " + Request.instance().getBookId() + " is not issued");
            break;
        case Result.OPERATION_COMPLETED:
            System.out.println("The hold has been removed");
            break;
        default:
            System.out.println("An error has occurred");
        }
    }

    /**
     * Method to be called for processing books. Prompts the user for the
     * appropriate values and uses the appropriate Library method for processing
     * books.
     * 
     */
    public void processHolds() {
        do {
            Request.instance().setBookId(getToken("Enter book id"));
            Result result = library.processHold(Request.instance());
            if (result.getResultCode() == Result.OPERATION_COMPLETED) {
                System.out.println("Book " + result.getBookTitle() + " should be issued to " + result.getMemberName()
                        + " phone " + result.getMemberPhone());
            } else if (result.getResultCode() == Result.BOOK_ISSUED) {
                System.out.println("This book " + result.getBookTitle() + " is still issued");
            } else {
                System.out.println("No valid holds left");
            }
            if (!yesOrNo("Process more books?")) {
                break;
            }
        } while (true);
    }

    /**
     * Method to be called for displaying transactions. Prompts the user for the
     * appropriate values and uses the appropriate Library method for displaying
     * transactions.
     * 
     */
    public void getTransactions() {
        Request.instance().setMemberId(getToken("Enter member id"));
        Request.instance().setDate(getDate("Please enter the date for which you want records as mm/dd/yy"));
        Iterator<Transaction> result = library.getTransactions(Request.instance());
        while (result.hasNext()) {
            Transaction transaction = result.next();
            System.out.println(transaction.getType() + "   " + transaction.getTitle() + "\n");
        }
        System.out.println("\n End of transactions \n");
    }

    /**
     * Displays all members
     */
    public void getMembers() {
        Iterator<Result> iterator = library.getMembers();
        System.out.println("List of members (name, address, phone, id)");
        while (iterator.hasNext()) {
            Result result = iterator.next();
            System.out.println(result.getMemberName() + " " + result.getMemberAddress() + " " + result.getMemberPhone()
                    + " " + result.getMemberId());
        }
        System.out.println("End of listing");
    }

    /**
     * Gets and prints all books.
     */
    public void getBooks() {
        Iterator<Result> iterator = library.getBooks();
        System.out.println("List of books (title, author, id, borrower id, due date)");
        while (iterator.hasNext()) {
            Result result = iterator.next();
            System.out.println(result.getBookTitle() + " " + result.getBookAuthor() + " " + result.getBookId() + " "
                    + result.getBookBorrower() + " " + result.getBookDueDate());
        }
        System.out.println("End of listing");
    }

    /**
     * Method to be called for saving the Library object. Uses the appropriate
     * Library method for saving.
     * 
     */
    private void save() {
        if (library.save()) {
            System.out.println(" The library has been successfully saved in the file LibraryData \n");
        } else {
            System.out.println(" There has been an error in saving \n");
        }
    }

    /**
     * Method to be called for retrieving saved data. Uses the appropriate Library
     * method for retrieval.
     * 
     */
    private void retrieve() {
        try {
            if (library == null) {
                library = Library.retrieve();
                if (library != null) {
                    System.out.println(" The library has been successfully retrieved from the file LibraryData \n");
                } else {
                    System.out.println("File doesnt exist; creating new library");
                    library = Library.instance();
                }
            }
        } catch (Exception cnfe) {
            cnfe.printStackTrace();
        }
    }

    /**
     * Orchestrates the whole process. Calls the appropriate method for the
     * different functionalities.
     * 
     */
    public void process() {
        int command;
        help();
        while ((command = getCommand()) != EXIT) {
            switch (command) {
            case ADD_MEMBER:
                addMember();
                break;
            case ADD_BOOKS:
                addBooks();
                break;
            case ISSUE_BOOKS:
                issueBooks();
                break;
            case RETURN_BOOKS:
                returnBooks();
                break;
            case REMOVE_BOOKS:
                removeBooks();
                break;
            case RENEW_BOOKS:
                renewBooks();
                break;
            case PLACE_HOLD:
                placeHold();
                break;
            case REMOVE_HOLD:
                removeHold();
                break;
            case PROCESS_HOLD:
                processHolds();
                break;
            case GET_TRANSACTIONS:
                getTransactions();
                break;
            case GET_MEMBERS:
                getMembers();
                break;
            case GET_BOOKS:
                getBooks();
                break;
            case GET_MEMBER_NAME:
                getMemberName();
                break;
            case SAVE:
                save();
                break;
            case HELP:
                help();
                break;
            }
        }
    }

    /**
     * The method to start the application. Simply calls process().
     * 
     * @param args not used
     */
    public static void main(String[] args) {
        UserInterface.instance().process();
    }

    public void getMemberName() {
        Request.instance().setMemberId(getToken("Enter member id: "));
        Result result = library.getMemberName(Request.instance());
        if (result.getResultCode() == Result.OPERATION_COMPLETED) {
            System.out.println(
                    "The name of the member with id " + result.getMemberId() + " is " + result.getMemberName());
        } else {
            System.out.println("The member you are interested in does not exist");
        }
    }

}