package states;

public class BusyState extends PhoneState {
    private static BusyState instance;

    private BusyState() {
    }

    public static BusyState instance() {
        if (instance == null) {
            instance = new BusyState();
        }
        return instance;
    }

    @Override
    public void enter() {
    }

    @Override
    public void leave() {
    }

}