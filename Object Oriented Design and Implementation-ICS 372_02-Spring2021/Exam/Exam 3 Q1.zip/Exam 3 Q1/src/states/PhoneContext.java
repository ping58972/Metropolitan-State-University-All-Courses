package states;

import display.PhoneDisplay;
import events.BusySignalEvent;
import events.ConnectedSignalEvent;
import events.DialingEvent;
import events.HangUpEvent;
import events.PickUpEvent;

public class PhoneContext {
    private PhoneDisplay display;
    private PhoneState currentState;
    private static PhoneContext instance;
    private int alarmValue;

    private PhoneContext() {
        instance = this;
        currentState = OffState.instance();
    }

    public static PhoneContext instance() {
        if (instance == null) {
            instance = new PhoneContext();
        }
        return instance;
    }

    public void setDisplay(PhoneDisplay display) {
        this.display = display;
        initialize();
    }

    public void initialize() {
        PhoneContext.instance().changeState(OffState.instance());
    }

    public void changeState(PhoneState nextState) {
        currentState.leave();
        System.out.println("Left " + currentState);
        currentState = nextState;
        currentState.enter();
        System.out.println("Entered " + currentState);
    }

    public void handleEvent(DialingEvent event) {
        currentState.handleEvent(event);
    }

    public void handleEvent(HangUpEvent event) {
        currentState.handleEvent(event);
    }

    public void handleEvent(BusySignalEvent event) {
        currentState.handleEvent(event);
    }

    public void handleEvent(ConnectedSignalEvent event) {
        currentState.handleEvent(event);
    }

    public void handleEvent(PickUpEvent event) {
        currentState.handleEvent(event);
    }

    public void showDialing() {
        display.showDialing();
    }

    public void showBusy() {
        display.showBusy();
    }

    public void showOff() {
        display.showOff();
    }

    public void showConnected() {
        display.showConnected();
    }

    public void showDialTone() {
        display.showDialTone();
    }

}