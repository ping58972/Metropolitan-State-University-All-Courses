package states;

public class ConnectedState extends PhoneState {
    private static ConnectedState connectedState;

    private ConnectedState() {

    }

    public static ConnectedState instance() {
        if (connectedState == null) {
            connectedState = new ConnectedState();
        }
        return connectedState;
    }

    public void enter() {
    }

    public void leave() {

    }

}