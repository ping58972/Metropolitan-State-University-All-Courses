package states;

public class OffState extends PhoneState {
    private static OffState instance;

    private OffState() {
    }

    public static OffState instance() {
        if (instance == null) {
            instance = new OffState();
        }
        return instance;
    }

    @Override
    public void enter() {
    }

    @Override
    public void leave() {
    }

}