package states;

public class DialToneState extends PhoneState {
    private static DialToneState instance;

    private DialToneState() {
        instance = this;
    }

    public static DialToneState instance() {
        if (instance == null) {
            instance = new DialToneState();
        }
        return instance;
    }

    @Override
    public void enter() {
    }

    @Override
    public void leave() {
    }

}