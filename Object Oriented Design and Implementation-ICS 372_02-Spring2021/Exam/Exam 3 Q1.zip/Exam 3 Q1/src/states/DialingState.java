package states;

public class DialingState extends PhoneState {
    private static DialingState instance;

    private DialingState() {
    }

    public static DialingState instance() {
        if (instance == null) {
            instance = new DialingState();
        }
        return instance;
    }

    @Override
    public void enter() {
    }

    @Override
    public void leave() {
    }

}