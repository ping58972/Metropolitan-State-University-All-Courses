package events;

public class PhoneEvent {

}
