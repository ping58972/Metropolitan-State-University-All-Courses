package events;

public class HangUpEvent extends PhoneEvent {
    private static HangUpEvent hangUpEvent;

    private HangUpEvent() {

    }

    public static HangUpEvent instance() {
        if (hangUpEvent == null) {
            hangUpEvent = new HangUpEvent();
        }
        return hangUpEvent;
    }
}