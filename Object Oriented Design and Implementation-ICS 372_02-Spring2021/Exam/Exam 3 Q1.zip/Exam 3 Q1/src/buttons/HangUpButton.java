package buttons;

import events.HangUpEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import states.PhoneContext;

public class HangUpButton extends GUIButton implements EventHandler<ActionEvent> {

    public HangUpButton(String string) {
        super(string);
    }

    @Override
    public void handle(ActionEvent event) {
        PhoneContext.instance().handleEvent(HangUpEvent.instance());
    }
}