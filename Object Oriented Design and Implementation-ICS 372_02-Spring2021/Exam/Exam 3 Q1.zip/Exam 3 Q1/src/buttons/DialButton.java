package buttons;

import events.DialingEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import states.PhoneContext;

public class DialButton extends GUIButton implements EventHandler<ActionEvent> {

    public DialButton(String string) {
        super(string);
    }

    @Override
    public void handle(ActionEvent event) {
        int time = 0;
        PhoneContext.instance().handleEvent(DialingEvent.instance());

    }
}