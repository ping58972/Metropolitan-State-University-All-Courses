package display;

import buttons.BusySignalButton;
import buttons.ConnectedSignalButton;
import buttons.DialButton;
import buttons.GUIButton;
import buttons.HangUpButton;
import buttons.PickUpButton;
import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import states.PhoneContext;

public class GUIDisplay extends Application implements PhoneDisplay {
    private GUIButton pickUpButton;
    private TextField phoneNumberField = new TextField("   ");
    private GUIButton hangUpButton;
    private GUIButton busySignalButton;
    private GUIButton connectedSignalButton;
    private GUIButton dialButton;

    private Text phoneStatus = new Text("Phone Status");
    private static PhoneDisplay display;
    private PhoneContext phoneContext;

    public static PhoneDisplay getInstance() {
        return display;
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        pickUpButton = new PickUpButton("Pick Up");
        busySignalButton = new BusySignalButton("Busy Signal");
        hangUpButton = new HangUpButton("Hang Up");
        connectedSignalButton = new ConnectedSignalButton("Connected");
        dialButton = new DialButton("Dial");
        GridPane pane = new GridPane();
        pane.setHgap(10);
        pane.setVgap(10);
        pane.setPadding(new Insets(10, 10, 10, 10));
        pane.add(phoneStatus, 0, 0);
        pane.add(phoneNumberField, 1, 0);
        pane.add(pickUpButton, 2, 0);
        pane.add(dialButton, 3, 0);
        pane.add(busySignalButton, 4, 0);
        pane.add(connectedSignalButton, 5, 0);
        pane.add(hangUpButton, 6, 0);
        Scene scene = new Scene(pane);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Phone Version 1");
        phoneContext = PhoneContext.instance();
        phoneContext.setDisplay(this);
        display = this;

        try {
            while (phoneContext == null) {
                Thread.sleep(1000);
            }
        } catch (Exception e) {

        }
        primaryStage.show();
        primaryStage.addEventHandler(WindowEvent.WINDOW_CLOSE_REQUEST, new EventHandler<WindowEvent>() {
            @Override
            public void handle(WindowEvent window) {
                System.exit(0);
            }
        });
    }

    @Override
    public void showOff() {
        phoneStatus.setText("Off");

    }

    @Override
    public void showDialTone() {
        phoneStatus.setText("Dial Tone");
    }

    @Override
    public void showDialing() {
        phoneStatus.setText("Dialing");

    }

    @Override
    public void showBusy() {
        phoneStatus.setText("Busy");

    }

    @Override
    public void showConnected() {
        phoneStatus.setText("Connected");

    }

}