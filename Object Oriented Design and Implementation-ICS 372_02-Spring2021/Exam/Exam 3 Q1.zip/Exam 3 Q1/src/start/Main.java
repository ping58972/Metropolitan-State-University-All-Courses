package start;

import display.GUIDisplay;
import display.PhoneDisplay;
import javafx.application.Application;
import states.PhoneContext;

public class Main {
    public static void main(String[] args) {
        new Thread() {
            @Override
            public void run() {
                Application.launch(GUIDisplay.class, null);
            }
        }.start();
        try {
            while (GUIDisplay.getInstance() == null) {
                Thread.sleep(1000);
            }
        } catch (InterruptedException ie) {
        }
        PhoneDisplay display = GUIDisplay.getInstance();
        PhoneContext.instance().setDisplay(display);
    }
}
