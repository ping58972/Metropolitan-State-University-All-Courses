package hotel;

public class DoubleRoom extends Room {

	public DoubleRoom(int roomNumber, double basicChargePerNight, double extraChargePerPersonPerNight) {
		super(roomNumber, basicChargePerNight, extraChargePerPersonPerNight);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void computeTotalChargePerNight(int numberOfGuests) throws Exception {
		if (numberOfGuests < 1 || numberOfGuests > 4) {
			throw new Exception("Invalid number of guests");
		}

		setTotalRentPerNight(
				getBasicChargePerNight() + Math.max(0, (numberOfGuests - 2)) * getExtraChargePerPersonPerNight());

	}

}
