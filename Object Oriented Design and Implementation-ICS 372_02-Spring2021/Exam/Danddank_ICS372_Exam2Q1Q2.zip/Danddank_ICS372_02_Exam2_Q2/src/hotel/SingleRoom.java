package hotel;

public class SingleRoom extends Room {

	public SingleRoom(int roomNumber, double basicChargePerNight, double extraChargePerPersonPerNight) {
		super(roomNumber, basicChargePerNight, extraChargePerPersonPerNight);
	}

	@Override
	public void computeTotalChargePerNight(int numberOfGuests) throws Exception {
		if (numberOfGuests < 1 || numberOfGuests > 2) {
			throw new Exception("Invalid number of guests");
		}
		setTotalRentPerNight(getBasicChargePerNight() + (numberOfGuests - 1) * getExtraChargePerPersonPerNight());

	}

}
