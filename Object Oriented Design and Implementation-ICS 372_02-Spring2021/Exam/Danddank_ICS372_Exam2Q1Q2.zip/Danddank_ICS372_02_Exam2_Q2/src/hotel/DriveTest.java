package hotel;

public class DriveTest {

	public static void main(String[] args) {
		Room singleRoom = new SingleRoom(1, 50.0, 10.0);
		Room doubleRoom = new DoubleRoom(2, 90.0, 20.0);
		Room suite = new SuiteRoom(3, 200.0, 50.0);
		try {
			singleRoom.computeTotalChargePerNight(2);
			assert singleRoom.getTotalRentPerNight() == 60.0;

		} catch (Exception e) {
			System.out.println(e);
		}
		try {
			singleRoom.computeTotalChargePerNight(1);
			assert singleRoom.getTotalRentPerNight() == 50.0;
		} catch (Exception e) {
			System.out.println(e);
		}
		try {
			singleRoom.computeTotalChargePerNight(3);
		} catch (Exception e) {
			System.out.println(e);
		}
		try {
			doubleRoom.computeTotalChargePerNight(4);
			assert doubleRoom.getTotalRentPerNight() == 130.0;
		} catch (Exception e) {
			System.out.println(e);
		}
		try {
			doubleRoom.computeTotalChargePerNight(2);
			assert doubleRoom.getTotalRentPerNight() == 90.0;
		} catch (Exception e) {
			System.out.println(e);
		}
		try {
			doubleRoom.computeTotalChargePerNight(5);
		} catch (Exception e) {
			System.out.println(e);
		}
		try {
			suite.computeTotalChargePerNight(4);
			assert suite.getTotalRentPerNight() == 200.0;
		} catch (Exception e) {
			System.out.println(e);
		}
		try {
			suite.computeTotalChargePerNight(8);
			assert suite.getTotalRentPerNight() == 400.0;
		} catch (Exception e) {
			System.out.println(e);
		}
		try {
			suite.computeTotalChargePerNight(9);
		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
