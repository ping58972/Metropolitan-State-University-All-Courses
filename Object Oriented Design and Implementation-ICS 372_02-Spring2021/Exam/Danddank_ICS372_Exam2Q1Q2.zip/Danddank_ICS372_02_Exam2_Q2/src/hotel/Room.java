package hotel;

/**
 * Implements the functionality for a room in a hotel. The field
 * totalRentPerNight stores the total rent for a single night in this room for
 * the specified number of guests.
 * 
 * @author Nalongsone Danddank
 *
 */
public abstract class Room {
	private int roomNumber;
	private double basicChargePerNight;
	private double extraChargePerPersonPerNight;
	private double totalRentPerNight;

	public Room(int roomNumber, double basicChargePerNight, double extraChargePerPersonPerNight) {
		this.roomNumber = roomNumber;
		this.basicChargePerNight = basicChargePerNight;
		this.extraChargePerPersonPerNight = extraChargePerPersonPerNight;
	}

	public int getRoomNumber() {
		return roomNumber;
	}

	public void setRoomNumber(int roomNumber) {
		this.roomNumber = roomNumber;
	}

	public double getBasicChargePerNight() {
		return basicChargePerNight;
	}

	public void setBasicChargePerNight(double basicChargePerNight) {
		this.basicChargePerNight = basicChargePerNight;
	}

	public double getExtraChargePerPersonPerNight() {
		return extraChargePerPersonPerNight;
	}

	public void setExtraChargePerPersonPerNight(double extraChargePerPersonPerNight) {
		this.extraChargePerPersonPerNight = extraChargePerPersonPerNight;
	}

	public double getTotalRentPerNight() {
		return totalRentPerNight;
	}

	public void setTotalRentPerNight(double totalRentPerNight) {
		this.totalRentPerNight = totalRentPerNight;
	}

	abstract public void computeTotalChargePerNight(int numberOfGuests) throws Exception;

}
