package hotel;

public class SuiteRoom extends Room {

	public SuiteRoom(int roomNumber, double basicChargePerNight, double extraChargePerPersonPerNight) {
		super(roomNumber, basicChargePerNight, extraChargePerPersonPerNight);
	}

	@Override
	public void computeTotalChargePerNight(int numberOfGuests) throws Exception {
		if (numberOfGuests < 1 || numberOfGuests > 8) {
			throw new Exception("Invalid number of guests");
		}
		setTotalRentPerNight(
				getBasicChargePerNight() + Math.max(0, (numberOfGuests - 4)) * getExtraChargePerPersonPerNight());

	}

}
