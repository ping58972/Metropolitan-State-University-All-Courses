package question1;

abstract class Ticket {
	private int serialNumber;
	private static int counter;

	public Ticket() {
		serialNumber = ++counter;
	}

	public int getSerialNumber() {
		return serialNumber;
	}

	public abstract double getPrice();

	@Override
	public String toString() {
		return "Ticket " + serialNumber + " price " + getPrice();
	}

}
