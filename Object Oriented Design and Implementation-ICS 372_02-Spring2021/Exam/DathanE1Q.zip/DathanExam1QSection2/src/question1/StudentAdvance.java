package question1;

public class StudentAdvance extends Advance {

	public StudentAdvance(int days) {
		super(days);
	}

	@Override
	public double getPrice() {
		return super.getPrice() / 2;
	}

	@Override
	public String toString() {
		return super.toString() + " bring an id to prove you are a student";
	}

}
