package question1;

public class Advance extends Ticket {
	private double price;

	public Advance(int days) {
		if (days >= 10) {
			price = 35;
		} else if (days > 0) {
			price = 45;
		} else {
			price = 50.0;
		}
	}

	@Override
	public double getPrice() {
		return price;
	}
}
