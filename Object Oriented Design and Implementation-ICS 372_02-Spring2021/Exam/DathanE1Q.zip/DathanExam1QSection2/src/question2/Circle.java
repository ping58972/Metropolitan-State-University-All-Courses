package question2;

public class Circle {
	private int centerX;
	private int centerY;
	private int radius;

	public int getRadius() {
		return radius;
	}

	public int getCenterX() {
		return centerX;
	}

	public int getCenterY() {
		return centerY;
	}

	public double getArea() {
		return 3.14 * radius * radius;
	}

	public Circle(int centerX, int centerY, int radius) {
		this.centerX = centerX;
		this.centerY = centerY;
		this.radius = radius;
	}
}
