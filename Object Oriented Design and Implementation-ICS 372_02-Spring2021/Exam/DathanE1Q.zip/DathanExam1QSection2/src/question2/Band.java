package question2;

public class Band {
	private Circle circle1;
	private Circle circle2;

	public Band(int centerX, int centerY, int width, int radius) throws Exception {
		if (width < radius) {
			circle1 = new Circle(centerX, centerY, radius);
			circle2 = new Circle(centerX, centerY, radius - width);
		} else {
			throw new Exception("Illegal parameters");
		}
	}

	public void display() {
		System.out.println("Centered at (" + circle1.getCenterX() + ", " + circle1.getCenterY() + ") width "
				+ (circle1.getRadius() - circle2.getRadius()));
	}

	public double getArea() {
		return circle1.getArea() - circle2.getArea();
	}
}
