/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package view;

/**
 * Implements a logical view. This displays all the shapes.
 */
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.Iterator;

import model.Model;
import model.shapes.Shape;

public class View implements PropertyChangeListener {
	private static View view;
	private PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);

	/**
	 * Private constructor for the singleton pattern
	 */
	private View() {
		Model.instance().addView(this);
	}

	/**
	 * Returns the only instance
	 * 
	 * @return the only instance
	 */
	public static View instance() {
		if (view == null) {
			view = new View();
		}
		return view;
	}

	/**
	 * Adds a physical view that would actually do the rendering.
	 * 
	 * @param physicalView the physical view
	 */
	public void addPhysicalView(PhysicalView physicalView) {
		propertyChangeSupport.addPropertyChangeListener(physicalView);
	}

	/**
	 * Removes a physical view.
	 * 
	 * @param physicalView the physical view
	 */
	public void removePhysicalView(PhysicalView physicalView) {
		propertyChangeSupport.removePropertyChangeListener(physicalView);
	}

	@Override
	public void propertyChange(PropertyChangeEvent event) {
		update();
	}

	/**
	 * Draws the shapes; called from the physical view
	 * 
	 * @param renderer the render for drawing (supplied by the physical view)
	 */
	public void draw(Renderer renderer) {
		for (PropertyChangeListener listener : propertyChangeSupport.getPropertyChangeListeners()) {
			Iterator<Shape> items = Model.instance().getShapes();
			while (items.hasNext()) {
				Shape item = items.next();
				item.render(renderer);
			}
		}
	}

	/**
	 * Changes the cursor in the drawing panel to the default cursor, whatever the
	 * current technology supports.
	 * 
	 */
	public void setCursorToDefault() {
		for (PropertyChangeListener listener : propertyChangeSupport.getPropertyChangeListeners()) {
			((PhysicalView) listener).setCursorToDefault();
		}
	}

	/**
	 * Changes the cursor in the drawing panel to indicate that a drawing is in
	 * progress, whatever the current technology supports.
	 * 
	 */
	public void setCursorToDrawing() {
		for (PropertyChangeListener listener : propertyChangeSupport.getPropertyChangeListeners()) {
			((PhysicalView) listener).setCursorToDrawing();
		}
	}

	/**
	 * Called when the view should be redrawn.
	 */
	public void update() {
		for (PropertyChangeListener listener : propertyChangeSupport.getPropertyChangeListeners()) {
			PhysicalView view = (PhysicalView) listener;
			view.propertyChange(null);
		}
	}
}
