package model.shapes;

import java.io.Serializable;

import view.Renderer;

/**
 * Superclass for all types of drawable objects.
 *
 */
public abstract class Shape implements Serializable {
	private static final long serialVersionUID = 1L;
	protected int red = 0;
	protected int green = 0;
	protected int blue = 255;

	/**
	 * Draw the figure on the UI
	 */
	public void render(Renderer renderer) {
		renderer.setColor(red, green, blue);
	}

	/**
	 * Sets the rendering color
	 * 
	 * @param red   red value 0-255
	 * @param green value 0-255
	 * @param blue  value 0-255
	 */
	public void setColor(int red, int green, int blue) {
		this.red = red;
		this.green = green;
		this.blue = blue;
	}

	public int getRed() {
		return red;
	}

	public int getGreen() {
		return green;
	}

	public int getBlue() {
		return blue;
	}

	@Override
	public String toString() {
		return "Shape [red=" + red + ", green=" + green + ", blue=" + blue + "]";
	}
}