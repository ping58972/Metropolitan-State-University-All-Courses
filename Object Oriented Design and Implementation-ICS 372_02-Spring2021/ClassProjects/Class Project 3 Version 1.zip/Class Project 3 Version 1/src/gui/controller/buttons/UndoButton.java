package gui.controller.buttons;

import controller.events.UndoRequestEvent;
import controller.states.DrawingContext;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;

/**
 * 
 * @author Brahma Dathan
 * 
 *         Redistribution and use with or without modification, are permitted
 *         provided that the following conditions are met: the use is for
 *         academic purpose only - Redistributions of source code must retain
 *         the above copyright notice, this list of conditions and the following
 *         disclaimer. - The name of Brahma Dathan may not be used to
 *         endorse or promote products derived from this software without
 *         specific prior written permission.
 *
 *         The author does not make any claims regarding the correctness of the
 *         code in this module and are not responsible for any loss or damage
 *         resulting from its use.
 */
/**
 * The button to invoke for undoing an action.
 * 
 * @author Brahma Dathan
 *
 */
public class UndoButton extends GUIButton implements EventHandler<ActionEvent> {
	/**
	 * The constructor for the button for issuing an undo
	 */
	public UndoButton() {
		super("Undo");
		this.setOnAction(this);
	}

	@Override
	public void handle(ActionEvent event) {
		DrawingContext.instance().handleEvent(UndoRequestEvent.instance());
	}
}