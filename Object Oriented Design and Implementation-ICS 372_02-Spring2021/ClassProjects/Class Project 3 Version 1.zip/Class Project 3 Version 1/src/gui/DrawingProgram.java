/**
 * 
 * @author Brahma Dathan
 * 
 *         Redistribution and use with or without modification, are permitted
 *         provided that the following conditions are met: the use is for
 *         academic purpose only - Redistributions of source code must retain
 *         the above copyright notice, this list of conditions and the following
 *         disclaimer. - The name of Brahma Dathan may not be used to
 *         endorse or promote products derived from this software without
 *         specific prior written permission.
 *
 *         The author does not make any claims regarding the correctness of the
 *         code in this module and are not responsible for any loss or damage
 *         resulting from its use.
 */
/**
 * The main program for drawing the shapes
 * 
 * @author Brahma Dathan
 *
 */
package gui;

import gui.controller.buttons.FXViewMenuItem;
import gui.controller.buttons.SwingViewMenuItem;
import gui.controller.handlers.KeyPressedHandler;
import gui.controller.handlers.KeyTypedHandler;
import gui.controller.handlers.MouseClickHandler;
import gui.panels.ButtonPanel;
import gui.panels.DrawingPanel;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

/**
 * The GUI for the program
 *
 */
public class DrawingProgram extends Application {
	private DrawingPanel drawingPanel;
	private ButtonPanel buttonPanel;

	private String fileName;

	/**
	 * Remembers the file name for storing in the title
	 * 
	 * @param fileName file name
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	/**
	 * returns the file name
	 * 
	 * @return file name
	 */
	public String getFileName() {
		return fileName;
	}

	/**
	 * Initializes the view by creating all the widgets
	 */
	@Override
	public void start(Stage primaryStage) {
		primaryStage.setTitle("Drawing Program Version 1");
		fileName = null;
		drawingPanel = new DrawingPanel();
		buttonPanel = new ButtonPanel();
		HBox hBox = new HBox();
		hBox.getChildren().add(buttonPanel);
		hBox.getChildren().add(drawingPanel);
		Scene scene = new Scene(hBox);
		scene.setOnKeyTyped(new KeyTypedHandler());
		drawingPanel.setOnMousePressed(new MouseClickHandler());
		scene.setOnKeyPressed(new KeyPressedHandler());
		MenuBar menuBar = new MenuBar();
		drawingPanel.getChildren().addAll(menuBar);
		Menu viewsMenu = new Menu("Views");
		MenuItem fxView = new FXViewMenuItem();
		MenuItem swingView = new SwingViewMenuItem();
		menuBar.getMenus().addAll(viewsMenu);
		viewsMenu.getItems().add(fxView);
		viewsMenu.getItems().add(swingView);
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	public static void main(String[] args) {
		Application.launch(args);
	}
}