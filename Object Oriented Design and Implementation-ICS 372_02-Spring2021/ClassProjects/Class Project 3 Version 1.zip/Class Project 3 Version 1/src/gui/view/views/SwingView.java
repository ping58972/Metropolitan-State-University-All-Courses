/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package gui.view.views;

import java.awt.Container;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JFrame;
import javax.swing.WindowConstants;

import gui.panels.SwingPanel;
import model.Model;
import view.View;

/**
 * A display-only view of the MVC architecture
 *
 */
public class SwingView extends JFrame {
  private static final long serialVersionUID = 1L;
  private SwingPanel drawingPanel;

  /**
   * Initializes the view by creating all the widgets
   */
  public SwingView() {
    super("Drawing Program Swing View");
    drawingPanel = new SwingPanel(Model.instance());
    Container contentpane = getContentPane();
    contentpane.add(drawingPanel);
    this.setSize(600, 600);
    this.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
    this.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent ev) {
        View.instance().removePhysicalView(drawingPanel);
        SwingView.this.dispose();

      }
    });
    this.pack();
    this.setVisible(true);
  }

}