package gui.panels;

/**
 * 
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan 
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
import gui.controller.buttons.LabelButton;
import gui.controller.buttons.LineButton;
import gui.controller.buttons.OpenButton;
import gui.controller.buttons.PolygonButton;
import gui.controller.buttons.RedoButton;
import gui.controller.buttons.SaveButton;
import gui.controller.buttons.UndoButton;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;

/**
 * Sets up the panel of buttons
 * 
 * @author Brahma Dathan
 */
public class ButtonPanel extends VBox {
	private Button lineButton;
	private Button polygonButton;
	private Button labelButton;
	private Button undoButton;
	private Button redoButton;
	private Button saveButton;
	private Button openButton;

	/**
	 * Creates all the buttons and puts them on the panel.
	 */
	public ButtonPanel() {
		polygonButton = new PolygonButton();
		lineButton = new LineButton();
		labelButton = new LabelButton();
		undoButton = new UndoButton();
		redoButton = new RedoButton();
		saveButton = new SaveButton();
		openButton = new OpenButton();
		setPrefHeight(lineButton.getHeight() * 12);
		setSpacing(5);
		this.getChildren().add(lineButton);
		this.getChildren().add(labelButton);
		this.getChildren().add(polygonButton);
		this.getChildren().add(saveButton);
		this.getChildren().add(openButton);
		this.getChildren().add(undoButton);
		this.getChildren().add(redoButton);
		setPadding(new Insets(10, 10, 10, 10));
	}
}
