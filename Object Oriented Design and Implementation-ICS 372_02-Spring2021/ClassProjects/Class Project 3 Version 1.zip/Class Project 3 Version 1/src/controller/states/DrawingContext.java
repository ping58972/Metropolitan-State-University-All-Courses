package controller.states;

import controller.Controller;
import controller.commands.Command;
import controller.events.AbandonEvent;
import controller.events.CharacterEvent;
import controller.events.ConfirmEvent;
import controller.events.ControlMouseClickEvent;
import controller.events.CreateLabelEvent;
import controller.events.CreateLineEvent;
import controller.events.CreatePolygonEvent;
import controller.events.DeleteCharacterEvent;
import controller.events.FXViewEvent;
import controller.events.MouseEnterEvent;
import controller.events.MouseExitEvent;
import controller.events.OpenRequestEvent;
import controller.events.PointInputEvent;
import controller.events.RedoRequestEvent;
import controller.events.SaveRequestEvent;
import controller.events.ShiftEnterKeyEvent;
import controller.events.SwingViewEvent;
import controller.events.UndoRequestEvent;

/**
 *
 * @author Brahma Dathan and Sarnath Ramnath
 * @Copyright (c) 2010

 * Redistribution and use with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - the use is for academic purpose only
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Neither the name of Brahma Dathan or Sarnath Ramnath
 *     may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * The authors do not make any claims regarding the correctness of the code in this module
 * and are not responsible for any loss or damage resulting from its use.
 */

/**
 * The context implements the Controller. It stores the current state and the
 * shape being worked on, for some commands.
 *
 */
public class DrawingContext implements Controller {
	private DrawingState currentState;
	private static DrawingContext instance;
	private Command command;

	/**
	 * Make it a singleton
	 */
	private DrawingContext() {
		currentState = QuiescentState.instance();
		changeCurrentState(currentState);
	}

	/**
	 * Return the instance
	 *
	 * @return the object
	 */
	public static DrawingContext instance() {
		if (instance == null) {
			instance = new DrawingContext();
		}
		return instance;
	}

	/**
	 * Called from the states to change the current state
	 *
	 * @param nextState the next state
	 */
	public void changeCurrentState(DrawingState nextState) {
		currentState.leave();
		currentState = nextState;
		currentState.enter();
	}

	public void setCommand(Command command) {
		this.command = command;
	}

	public Command getCommand() {
		return command;
	}

	/**
	 * Handles the request to create a line.
	 *
	 * @param event - the event that represents line creation
	 */
	@Override
	public void handleEvent(CreateLineEvent event) {
		currentState.handleEvent(event);
	}

	/**
	 * Handles the request to create a label.
	 *
	 * @param event - the event that represents label creation
	 */

	@Override
	public void handleEvent(CreateLabelEvent event) {
		currentState.handleEvent(event);
	}

	/**
	 * Handles a mouse click.
	 *
	 * @param event - the event that represents a mouse click
	 */
	@Override
	public void handleEvent(PointInputEvent event) {
		currentState.handleEvent(event);
	}

	@Override
	public void handleEvent(ShiftEnterKeyEvent event) {
		currentState.handleEvent(event);
	}

	/**
	 * Handles a mouse click with control down.
	 *
	 * @param event - the event that represents a mouse click
	 */
	@Override
	public void handleEvent(ControlMouseClickEvent event) {
		currentState.handleEvent(event);
	}

	/**
	 * Handles the input of a character
	 *
	 * @param event - the event that represents a character input
	 */
	@Override
	public void handleEvent(CharacterEvent event) {
		currentState.handleEvent(event);
	}

	/**
	 * Handles the pressing of the BackSpace key to delete a character
	 *
	 * @param event - the event that represents Enter key pressing
	 */
	@Override
	public void handleEvent(DeleteCharacterEvent event) {
		currentState.handleEvent(event);
	}

	@Override
	public void handleEvent(ConfirmEvent event) {
		currentState.handleEvent(event);
	}

	@Override
	public void handleEvent(AbandonEvent event) {
		currentState.handleEvent(event);
	}

	@Override
	public void handleEvent(CreatePolygonEvent event) {
		currentState.handleEvent(event);
	}

	@Override
	public void handleEvent(MouseEnterEvent event) {
		currentState.handleEvent(event);
	}

	@Override
	public void handleEvent(MouseExitEvent event) {
		currentState.handleEvent(event);
	}

	@Override
	public void handleEvent(FXViewEvent event) {
		currentState.handleEvent(event);
	}

	@Override
	public void handleEvent(SwingViewEvent event) {
		currentState.handleEvent(event);
	}

	/**
	 * Handles the request to undo a shape creation.
	 * 
	 * @param event - the event that represents undo
	 */
	public void handleEvent(UndoRequestEvent event) {
		currentState.handleEvent(event);
	}

	/**
	 * Handles the request to redo a shape creation.
	 * 
	 * @param event - the event that represents redo
	 */
	public void handleEvent(RedoRequestEvent event) {
		currentState.handleEvent(event);
	}

	/**
	 * Handles the request to save a file.
	 *
	 * @param event - the event that represents save request
	 */
	public void handleEvent(SaveRequestEvent event) {
		currentState.handleEvent(event);
	}

	/**
	 * Handles the request to open a file.
	 *
	 * @param event - the event that represents open request
	 */
	public void handleEvent(OpenRequestEvent event) {
		currentState.handleEvent(event);
	}
}