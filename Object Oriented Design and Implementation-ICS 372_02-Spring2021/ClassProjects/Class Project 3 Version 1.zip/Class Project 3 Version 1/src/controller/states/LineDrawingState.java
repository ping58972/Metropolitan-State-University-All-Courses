package controller.states;

/**
 * Processes the command to draw a line
 * 
 * @author Brahma Dathan
 *
 */
import controller.UndoManager;
import controller.commands.Command;
import controller.commands.LineCommand;
import controller.events.PointInputEvent;
import javafx.geometry.Point2D;
import view.View;

public class LineDrawingState extends DrawingState {
	private static LineDrawingState instance;

	/**
	 * Private constructor to make it a singleton
	 */
	private LineDrawingState() {

	}

	/**
	 * Gets the instance of the singleton class
	 * 
	 * @return the only instance of this class
	 */
	public static LineDrawingState instance() {
		if (instance == null) {
			instance = new LineDrawingState();
		}
		return instance;
	}

	@Override
	public void handleEvent(PointInputEvent event) {
		Command command = DrawingContext.instance().getCommand();
		if (command == null) {
			command = new LineCommand(new Point2D(event.getX(), event.getY()));
			DrawingContext.instance().setCommand(command);
			UndoManager.instance().beginCommand(command);
			View.instance().update();
		} else {
			((LineCommand) command).setPoint(1, new Point2D(event.getX(), event.getY()));
			View.instance().update();
			DrawingContext.instance().setCommand(null);
			DrawingContext.instance().changeCurrentState(QuiescentState.instance());
			UndoManager.instance().endCommand();
		}
	}
}
