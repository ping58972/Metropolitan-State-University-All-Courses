package controller.states;

/**
 * Processes the command to draw a polygon
 * 
 * @author Brahma Dathan
 *
 */
import controller.UndoManager;
import controller.commands.Command;
import controller.commands.PolygonCommand;
import controller.events.ConfirmEvent;
import controller.events.PointInputEvent;
import javafx.geometry.Point2D;
import view.View;

public class PolygonDrawingState extends DrawingState {
	private static PolygonDrawingState instance;
	private int numberOfPoints;

	/**
	 * Private constructor to make the class a singleton
	 */
	private PolygonDrawingState() {
	}

	/**
	 * Gets the instance of the singleton class
	 * 
	 * @return the only instance of this class
	 */
	public static PolygonDrawingState instance() {
		if (instance == null) {
			instance = new PolygonDrawingState();
		}
		return instance;
	}

	@Override
	public void handleEvent(PointInputEvent event) {
		Command command = DrawingContext.instance().getCommand();
		if (command == null) {
			command = new PolygonCommand(new Point2D(event.getX(), event.getY()));
			DrawingContext.instance().setCommand(command);
			UndoManager.instance().beginCommand(command);
		}
		((PolygonCommand) command).addPoint(new Point2D(event.getX(), event.getY()));
		View.instance().update();
		numberOfPoints++;
	}

	@Override
	public void handleEvent(ConfirmEvent event) {
		if (numberOfPoints >= 3) {
			Command command = DrawingContext.instance().getCommand();
			command.end();
			View.instance().update();
			DrawingContext.instance().setCommand(null);
			DrawingContext.instance().changeCurrentState(QuiescentState.instance());
		}
	}
}
