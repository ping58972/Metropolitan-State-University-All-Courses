/**
 * 
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan 
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package controller;

import controller.events.AbandonEvent;
import controller.events.CharacterEvent;
import controller.events.ConfirmEvent;
import controller.events.ControlMouseClickEvent;
import controller.events.CreateLabelEvent;
import controller.events.CreateLineEvent;
import controller.events.CreatePolygonEvent;
import controller.events.DeleteCharacterEvent;
import controller.events.FXViewEvent;
import controller.events.MouseEnterEvent;
import controller.events.MouseExitEvent;
import controller.events.PointInputEvent;
import controller.events.RedoRequestEvent;
import controller.events.ShiftEnterKeyEvent;
import controller.events.SwingViewEvent;
import controller.events.UndoRequestEvent;

/**
 * This represents the controller functionality.
 * 
 * @author Brahma Dathan
 *
 */
public interface Controller {
	/**
	 * What to do when a line is to be created.
	 * 
	 * @param event represents the click on the button
	 */
	public void handleEvent(CreateLineEvent event);

	/**
	 * What to do when mouse enters the drawing panel.
	 * 
	 * @param event represents the entry of the mouse
	 */
	public void handleEvent(MouseEnterEvent event);

	/**
	 * What to do when mouse exits the drawing panel.
	 * 
	 * @param event represents the exit of the mouse
	 */
	public void handleEvent(MouseExitEvent event);

	/**
	 * What to do when mouse is clicked with control down.
	 * 
	 * @param event represents the click of the mouse with control down
	 */
	public void handleEvent(ControlMouseClickEvent event);

	/**
	 * What to do when the Enter key is pressed with shift down.
	 * 
	 * @param event represents the Enter key press with shift down
	 */
	public void handleEvent(ShiftEnterKeyEvent event);

	/**
	 * What to do when mouse is clicked.
	 * 
	 * @param event represents the click of the mouse
	 */
	public void handleEvent(PointInputEvent event);

	/**
	 * What to do when a polygon is to be created.
	 * 
	 * @param event represents the click on the button
	 */
	public void handleEvent(CreatePolygonEvent event);

	/**
	 * What to do when a label is to be created.
	 * 
	 * @param event represents the click on the button
	 */
	public void handleEvent(CreateLabelEvent event);

	/**
	 * What to do when a character is typed.
	 * 
	 * @param event represents the typing of the key
	 */
	public void handleEvent(CharacterEvent event);

	/**
	 * What to do when backspace key is pressed.
	 * 
	 * @param event represents the pressing of the key
	 */
	public void handleEvent(DeleteCharacterEvent event);

	/**
	 * What to do when escape key is pressed.
	 * 
	 * @param event represents the pressing of the key
	 */
	public void handleEvent(AbandonEvent event);

	/**
	 * What to do when enter key is pressed.
	 * 
	 * @param event represents the pressing of the key
	 */
	public void handleEvent(ConfirmEvent event);

	/**
	 * Handles the request to process the request to create an FX View
	 * 
	 * @param event distinguishes this method from the others
	 */
	public void handleEvent(FXViewEvent event);

	/**
	 * Handles the request to process the request to create an swing View
	 * 
	 * @param event distinguishes this method from the others
	 */
	public void handleEvent(SwingViewEvent event);

	/**
	 * Handles the request to undo a shape creation.
	 * 
	 * @param event - the event that represents undo
	 */
	public void handleEvent(UndoRequestEvent event);

	/**
	 * Handles the request to redo a shape creation.
	 * 
	 * @param event - the event that represents redo
	 */
	public void handleEvent(RedoRequestEvent event);
}
