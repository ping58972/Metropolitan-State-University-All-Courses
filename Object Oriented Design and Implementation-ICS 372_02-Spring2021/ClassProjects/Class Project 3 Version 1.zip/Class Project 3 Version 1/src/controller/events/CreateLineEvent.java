/**
 * 
 * @author Brahma Dathan
 * 
 *         Redistribution and use with or without modification, are permitted
 *         provided that the following conditions are met: the use is for
 *         academic purpose only - Redistributions of source code must retain
 *         the above copyright notice, this list of conditions and the following
 *         disclaimer. - The name of Brahma Dathan may not be used to
 *         endorse or promote products derived from this software without
 *         specific prior written permission.
 *
 *         The author does not make any claims regarding the correctness of the
 *         code in this module and are not responsible for any loss or damage
 *         resulting from its use.
 */
package controller.events;

/**
 * 
 * The event is generated when the user clicks on the Line button
 *
 */
public class CreateLineEvent extends DrawingEvent {
    private static CreateLineEvent instance;

    /**
     * Constructor is private to implement the singleton pattern.
     */
    private CreateLineEvent() {
    }

    /**
     * Static method to return the only instance of the class.
     * 
     * @return - the only instance
     */
    public static CreateLineEvent instance() {
        if (instance == null) {
            instance = new CreateLineEvent();
        }
        return instance;
    }

}
