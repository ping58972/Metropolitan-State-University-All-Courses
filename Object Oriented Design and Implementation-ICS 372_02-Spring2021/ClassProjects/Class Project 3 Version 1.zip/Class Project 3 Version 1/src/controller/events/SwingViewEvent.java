package controller.events;

/**
 * Represents the event to view the drawing through a swing view
 * 
 * @author Brahma Dathan
 *
 */
public class SwingViewEvent extends DrawingEvent {
	private static SwingViewEvent instance;

	/**
	 * Private constructor for implementing the singleton pattern.
	 */
	private SwingViewEvent() {
	}

	/**
	 * Static method to return the only instance of the class.
	 * 
	 * @return - the only instance
	 */
	public static SwingViewEvent instance() {
		if (instance == null) {
			instance = new SwingViewEvent();
		}
		return instance;
	}
}
