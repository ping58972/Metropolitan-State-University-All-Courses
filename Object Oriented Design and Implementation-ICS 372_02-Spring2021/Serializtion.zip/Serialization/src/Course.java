import java.io.Serializable;

public class Course implements Serializable {
	private String name;
	private int credits;

	public Course(String name, int credits) {
		super();
		this.name = name;
		this.credits = credits;
	}

}
