import java.io.Serializable;
import java.util.LinkedList;
import java.util.List;

public class CourseCollection implements Serializable {
	private List courses = new LinkedList();

	public void addCourse(Course course) {
		courses.add(course);
	}
}
