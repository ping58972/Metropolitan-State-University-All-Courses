import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Driver {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		CourseCollection collection = new CourseCollection();
		collection.addCourse(new Course("ics 372", 4));
		FileOutputStream file = new FileOutputStream("objectData");
		ObjectOutputStream output = new ObjectOutputStream(file);
		output.writeObject(collection);
		output.close();
		FileInputStream file2 = new FileInputStream("objectData");
		ObjectInputStream input2 = new ObjectInputStream(file2);
		CourseCollection collection2 = (CourseCollection) input2.readObject();
	}
}
