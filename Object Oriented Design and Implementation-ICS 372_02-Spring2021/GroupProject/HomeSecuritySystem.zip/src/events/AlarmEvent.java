package events;

/**
 * This is the super class for all events. Serves no use right now, but may be
 * useful in the future.
 *
 */
public class AlarmEvent {

}
