# Grocery Store Application Project
#### Project's Members:

	Nalongsone Danddank,
	Rich Fritz,
	Ryan Kinsella,
	Gilbert Ponsness,
	Marc Wedo

### Course infos:
	Group Project
	Computer Science's 
	ICS372-02
	From 21-MAR-2021 to 2-April-2021
### Detail:
	A small co-op grocery store works by having members join it by paying a certain fee.

 
 @author Brahma Dathan and Sarnath Ramnath
 @Copyright (c) 2010
 
 Redistribution and use with or without
 modification, are permitted provided that the following conditionsare met:
 
    - the use is for academic purpose only
    - Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    - Neither the name of Brahma Dathan or Sarnath Ramnath
      may be used to endorse or promote products derived
      from this software without specific prior written permission.
 
  The authors do not make any claims regarding the correctness of the code in this module
  and are not responsible for any loss or damage resulting from its use.  
