package InitialCodebase;

import java.io.File;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

// Class DelivC does the work for deliverable DelivC of the Prog340

public class DelivC {

	File inputFile;
	File outputFile;
	PrintWriter output;
	Graph g;

	public DelivC(File in, Graph gr) {
		inputFile = in;
		g = gr;

		// Get output file name.
		String inputFileName = inputFile.toString();
		String baseFileName = inputFileName.substring(0, inputFileName.length() - 4); // Strip off ".txt"
		String outputFileName = baseFileName.concat("_out.txt");
		outputFile = new File(outputFileName);
		if (outputFile.exists()) { // For retests
			outputFile.delete();
		}

		try {
			output = new PrintWriter(outputFile);
		} catch (Exception x) {
			System.err.format("Exception: %s%n", x);
			System.exit(0);
		}
		Graph result = ID_search(g);
		System.out.println("\n\nThe final Goal" + result);
		System.out.println("DelivC:  To be implemented");
		output.println("DelivC:  To be implemented");
		output.flush();
	}

	private Graph ID_search(Graph G) {
		boolean hasAnyNeighbors[] = { true };
		int bound = 1;
		Node startNode = findNode(G, "S");
//		System.out.println(startNode);
		Graph path = new Graph();
		path.addNode(startNode);
		while (hasAnyNeighbors[0]) {
			hasAnyNeighbors[0] = false;
			Graph res = depth_bounded_search(path, bound, hasAnyNeighbors);
			if (res != null) {
				return res;
			}
			System.out.println("" + bound + " " + hasAnyNeighbors[0]);
			bound++;

		}

		return null;
	}

	private Graph depth_bounded_search(Graph path, int b, boolean[] hasAnyNeighbors) {
//		hasAnyNeighbors[0] = true;
		if (b > 0) {

			Graph foundNode = null;
			path.addNode(null);
//			foundNode = depth_bounded_search(path, b, hasAnyNeighbors);

//			if (foundNode != null) {
//				return foundNode;
//
//			}

		} else if (path.getNodeList().get(-1).getAbbrev().equals("G")) {
			return path;
		} else if (path.getNodeList().get(-1).getOutgoingEdges().size() != 0) {
			hasAnyNeighbors[0] = true;
		}

		return null;
	}

	private Node findNode(Graph G, String s) {
		for (Node n : G.nodeList) {
			if (n.getVal().equals(s)) {
				return n;
			}
		}
		return null;
	}

	private ArrayList<Node> getSortedChildrenList(Node node) {
		ArrayList<Node> nodes = new ArrayList<Node>();
		ArrayList<Edge> edges = node.getOutgoingEdges();
		Collections.sort(edges, new Comparator<Edge>() {

			@Override
			public int compare(Edge o1, Edge o2) {
				// Fixed this bug, and get correct answer.
				if (o1.getDist() > o2.getDist()) {
					return 1;
				} else if (o1.getDist() == o2.getDist()) {
					return o1.getHead().getAbbrev().compareToIgnoreCase(o2.getHead().getAbbrev());
				} else {
					return -1;
				}
			}
		});
		for (Edge e : edges) {
			nodes.add(e.getHead());
		}
		return nodes;
	}
}

//class Path {
//	Path[] nodePaths;
//	int value;
//}

//private Node ID_search(Graph G) {
////	boolean hit_depth_bound = true;
//	boolean hasAnyNeighbors[] = { true };
//	int bound = 0;
//	Node startNode = findNode(G, "S");
//	System.out.println(startNode);
////	List<Node> visitedNodes = new ArrayList<Node>();
//
//	while (hasAnyNeighbors[0]) {
//		Set<Node> visitedNodes = new LinkedHashSet<Node>();
//		Node res = Depth_bounded_search(startNode, bound, hasAnyNeighbors, visitedNodes);
//		if (res != null) {
////			System.out.println(res.name);
//			System.out.println(visitedNodes);
//			return res;
//		}
////		visitedNodes = new LinkedHashSet<Node>();
//		System.out.println("increating bound: " + bound);
//
//		bound++;
//
//	}
//
//	return null;
//}
//
//private Node Depth_bounded_search(Node currentNode, int b, boolean[] hasAnyNeighbors, Set<Node> visitedNodes) {
//	System.out.println("Visitted Node: " + currentNode.abbrev + "  " + currentNode.name + "  bound: " + b);
//	visitedNodes.add(currentNode);
//	if (b > 0) {
////		System.out.println(currentNode.name + "   " + currentNode.getAbbrev());
//
//		for (Node node : getSortedChildrenList(currentNode)) {
////			System.out.println(node.name + "  " + node.abbrev);
//			Node foundNode = null;
//			if (!visitedNodes.contains(node)) {
//				foundNode = Depth_bounded_search(node, b - 1, hasAnyNeighbors, visitedNodes);
////			
//
//				if (foundNode != null) {
////				System.out.println(foundNode.getName() + "  " + foundNode.abbrev);
//					return foundNode;
//				}
//			}
//		}
//
//	} else if (b == 0 && currentNode.getVal().equals("G")) {
//		System.out.println("---**---" + currentNode.name);
//		return currentNode;
//	} else if (currentNode.getOutgoingEdges().size() == 0) {
//		hasAnyNeighbors[0] = false;
//	}
//
//	return null;
//}