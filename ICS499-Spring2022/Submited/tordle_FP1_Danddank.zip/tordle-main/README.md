# tordle

Wordle game for Telugu


By Nalongsone Danddank.
