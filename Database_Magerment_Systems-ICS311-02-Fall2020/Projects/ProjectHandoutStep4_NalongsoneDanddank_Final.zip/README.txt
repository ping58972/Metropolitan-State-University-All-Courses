#### Nalongsone Danddank	Student ID :�14958950	StarID: jf3893pd
#### Email: nalongsone.danddank@my.metrostate.edu
#### Metropolitan State University
#### ICS 311 � Database Implementation on MySQL

Please follow by below instruction:

# Create local Database:

In MySQL work bench:

Create new connection with local database:

Network address: 127.0.0.1

User: root
Password: root

Then run the my attached "ProjectHandoutStep4_NalongsoneDanddank.sql" script inside folder "database_script" for the new connection to create the database that my app will connect to.

# For Non-IT person OR Non-Programmer:

Go ahead run or execute "FinalProject.jar" file.


# For Programmer or IT:

To run the .java files:

1.create a new java project with any name

2.create 2 packet within the new project with the names: "Reataurant","Database".

3.create 4 new classes within the new project with the names that belong to the packet:
	"Reataurant"
		"GUI.java"
		"Main.java"
	"Database"
		"ConnectionFactory.java"
		"TableQueryDao.java"

4.copy and paste the contents of each .java files that I submitted into the corresponding class names that you created. 
   For example: copy the code content from my "GUI.java" file into your "GUI"  class.

5.You need to add the jar file to your project Build Path.
	 In Eclipse:
	Project->Properties->Java Build Path -> Add External jars 
	Choose the jar file in the folder �libs\mysql-connector-java-8.0.22.jar�

6.Then right click on "Main.java" in your package "Reataurant" explorer path > Run as > Java Application.

In the Menu of User Form GUI page:

"Next" will show the next row of the User table
"Previous" will show the previous row of the User  table
"Last" will show the last row of the User  table
"First" will show the first row of the User  table

In the Menu of "Item Form" GUI page:

"Next" will show the next row of the Item table where join with User Table for identify Chef id and name;
"Previous" will show the previous row of the Item table where join with User Table for identify Chef id and name;
"Last" will show the last row of the Item table where join with User Table for identify Chef id and name;
"First" will show the first row of theItem table where join with User Table for identify Chef id and name;

In the Menu of "Order Form" GUI page:

Devided into two parts.
the first part reads input from the user (Order ID which only input from order table id).
when click "submit" button, it will take the "Order ID" and retrieve information from the database table like Order table, user table and item table 
which corresponding order_item and user table, then display on "Food Item List of each Order" by Order Id which you input.

## For Setup the database 

Setup user and password and other infos for connection to database: all are belong in the "ConnectionFactory.java" file.  



#Screenshots: (in "images" folder)
Form 1.png Contains a picture of User Form
Form 2.png Contains a picture of Item Form
Form 3.png Contains a picture of Order Form
.
.
.
	


