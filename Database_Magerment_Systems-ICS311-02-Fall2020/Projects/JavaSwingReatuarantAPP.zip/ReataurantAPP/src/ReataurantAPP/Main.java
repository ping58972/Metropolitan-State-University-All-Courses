/**
 * 
 */
package ReataurantAPP;

import ReataurantAPP.GUI.Controller_GUI;

/**
 * @author Nalongsone Danddank
 *
 */
public class Main {

	public static void main(String[] args) {
		  new Controller_GUI();

	}

}
